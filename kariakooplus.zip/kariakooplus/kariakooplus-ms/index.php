<?php
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Slim\Http\UploadedFile;

require_once("vendor/autoload.php");
 
 
$settings = require __DIR__ . '/api/settings.php';
$app =new \Slim\App($settings);

// Set up dependencies
require __DIR__ . '/api/definition.php';

// Set up dependencies
require __DIR__ . '/api/dependencies.php';

// Register middleware
require __DIR__ . '/api/middleware.php';

// Register routes
require __DIR__ . '/api/routes.php';

$app->run();
?>