
DROP TABLE IF EXISTS events;
CREATE SEQUENCE events_seq;

CREATE TABLE IF NOT EXISTS events (
  id int NOT NULL DEFAULT NEXTVAL ('events_seq'),
  title varchar(200) NOT NULL,
  startdate varchar(50) NOT NULL,
  enddate varchar(50) NOT NULL,
  color varchar(100) NOT NULL,
  text_color varchar(50) NOT NULL DEFAULT '#fff',
  created_at timestamp(0) NOT NULL,
  updated_at timestamp(0) NOT NULL,
  PRIMARY KEY (id)
);

ALTER SEQUENCE events_seq RESTART WITH 6;

--
-- Dumping data for table `events`
--

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS project;
CREATE TABLE IF NOT EXISTS project (
  project_id varchar(100) NOT NULL,
  project_name varchar(250) NOT NULL,
  description text,
  status varchar(200) DEFAULT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  created_at timestamp(0) NOT NULL,
  created_by int NOT NULL,
  updated_at timestamp(0) NOT NULL,
  total_pharse int NOT NULL DEFAULT '7',
  complete_pharse int DEFAULT '0',
  budgeted_cost double precision NOT NULL DEFAULT '0',
  actual_cost double precision NOT NULL DEFAULT '0',
  total_bill double precision NOT NULL DEFAULT '0',
  PRIMARY KEY (project_id)
);

-- --------------------------------------------------------

--
-- Table structure for table `project_bill`
--

DROP TABLE IF EXISTS project_bill;
CREATE SEQUENCE project_bill_seq;

CREATE TABLE IF NOT EXISTS project_bill (
  id int NOT NULL DEFAULT NEXTVAL ('project_bill_seq'),
  project_id varchar(100) NOT NULL,
  description varchar(200) NOT NULL,
  amount double precision NOT NULL,
  created_at timestamp(0) NOT NULL,
  updated_at timestamp(0) NOT NULL,
  created_by int NOT NULL,
  PRIMARY KEY (id)
);

ALTER SEQUENCE project_bill_seq RESTART WITH 4;

-- --------------------------------------------------------

--
-- Table structure for table `project_cost`
--

DROP TABLE IF EXISTS project_cost;
CREATE SEQUENCE project_cost_seq;

CREATE TABLE IF NOT EXISTS project_cost (
  id int NOT NULL DEFAULT NEXTVAL ('project_cost_seq'),
  project_id varchar(100) NOT NULL,
  description varchar(200) NOT NULL,
  budgeted_cost double precision NOT NULL,
  actual_cost double precision NOT NULL,
  created_at timestamp(0) NOT NULL,
  updated_at timestamp(0) NOT NULL,
  created_by int NOT NULL,
  PRIMARY KEY (id)
);

ALTER SEQUENCE project_cost_seq RESTART WITH 7;

-- --------------------------------------------------------

--
-- Table structure for table `project_files`
--

DROP TABLE IF EXISTS project_files;
CREATE SEQUENCE project_files_seq;

CREATE TABLE IF NOT EXISTS project_files (
  id int NOT NULL DEFAULT NEXTVAL ('project_files_seq'),
  description varchar(200) NOT NULL,
  project_id varchar(100) NOT NULL,
  file_name varchar(200) NOT NULL,
  created_at timestamp(0) NOT NULL,
  created_by int NOT NULL,
  updated_at timestamp(0) NOT NULL,
  PRIMARY KEY (id)
);

ALTER SEQUENCE project_files_seq RESTART WITH 16;

-- --------------------------------------------------------

--
-- Table structure for table `project_pharse`
--

DROP TABLE IF EXISTS project_pharse;
CREATE SEQUENCE project_pharse_seq;

CREATE TABLE IF NOT EXISTS project_pharse (
  pharse_id int NOT NULL DEFAULT NEXTVAL ('project_pharse_seq'),
  project_id varchar(100) NOT NULL,
  pharse_name varchar(200) NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  status varchar(200) DEFAULT NULL,
  department int NOT NULL,
  accontable int NOT NULL,
  total_task int NOT NULL DEFAULT '0',
  complete_task int NOT NULL DEFAULT '0',
  created_at timestamp(0) NOT NULL,
  updated_at timestamp(0) NOT NULL,
  created_by int NOT NULL,
  PRIMARY KEY (pharse_id)
);

-- --------------------------------------------------------

--
-- Table structure for table `project_task`
--

DROP TABLE IF EXISTS project_task;
CREATE SEQUENCE project_task_seq;

CREATE TABLE IF NOT EXISTS project_task (
  task_id int NOT NULL DEFAULT NEXTVAL ('project_task_seq'),
  pharse_id int NOT NULL,
  task_name varchar(100) NOT NULL,
  description varchar(200) DEFAULT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  status varchar(50) NOT NULL DEFAULT 'Pending',
  created_at timestamp(0) NOT NULL,
  created_by int NOT NULL,
  updated_at timestamp(0) NOT NULL,
  accountable varchar(200) DEFAULT NULL,
  PRIMARY KEY (task_id)
);

ALTER SEQUENCE project_task_seq RESTART WITH 2;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS staff;
CREATE SEQUENCE staff_seq;

CREATE TABLE IF NOT EXISTS staff (
  staff_id int NOT NULL DEFAULT NEXTVAL ('staff_seq'),
  first_name varchar(200) NOT NULL,
  last_name varchar(200) NOT NULL,
  gender varchar(100) NOT NULL,
  email varchar(200) NOT NULL,
  password varchar(200) NOT NULL,
  position varchar(100) NOT NULL,
  created_at timestamp(0) NOT NULL,
  updated_at timestamp(0) NOT NULL,
  created_by varchar(100) NOT NULL,
  PRIMARY KEY (staff_id)
);

ALTER SEQUENCE staff_seq RESTART WITH 3;
COMMIT;
