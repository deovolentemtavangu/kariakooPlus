<?php

use Api\Middleware\AuthMiddleware;

//============================================================
// users  Routes
//============================================================
$app->post("/user/authenticate1","UserController:authenticateUser");
$app->get("/user/getTokenData1","UserController:getTokenData1");
$app->post("/user/registerUser","UserController:registeruser");
$app->get("/user/getUsers","UserController:getusers");
$app->post("/user/deletesUer/{id}","UserController:deleteuser");
$app->post("/user/editUser/{id}","UserController:edituser");
$app->get("/user/getUserById/{id}","UserController:getuserById");




//============================================================+
// Start Staff Routes
//============================================================
$app->post("/user/authenticate","StaffController:authenticateUser");
$app->get("/user/getTokenData","StaffController:getTokenData");
$app->post("/user/registerStaff","StaffController:registerStaff");
$app->get("/user/getStaffs","StaffController:getStaffs");
$app->post("/user/deleteStaff/{id}","StaffController:deleteStaff");
$app->post("/user/editStaff/{id}","StaffController:editStaff");
$app->get("/user/getStaffById/{id}","StaffController:getStaffById");


/*$app->group('', function () {

$this->post("/user/registerStaff","StaffController:registerStaff");
$this->get("/user/getStaffs","StaffController:getStaffs");
$this->post("/user/deleteStaff/{id}","StaffController:deleteStaff");
$this->post("/user/editStaff/{id}","StaffController:editStaff");
$this->get("/user/getStaffById/{id}","StaffController:getStaffById");

})->add(new AuthMiddleware($container));
*/

//============================================================+
// End Staff Routes
//============================================================










//============================================================+
// Start Project Routes
//============================================================
$app->post("/project/registerProject","ProjectController:registerProject");
$app->get("/project/getProjects","ProjectController:getProjects");
$app->post("/project/deleteProject/{id}","ProjectController:deleteProject");
$app->post("/project/editProject/{id}","ProjectController:editProject");
$app->get("/project/getProjectById/{id}","ProjectController:getProjectById");
//============================================================+
// End Project Routes
//============================================================






//============================================================+
// Start Pharse Routes
//============================================================
$app->post("/pharse/registerPharse","PharseController:registerPharse");
$app->get("/pharse/getPharses","PharseController:getPharses");
$app->post("/pharse/deletePharse/{id}","PharseController:deletePharse");
$app->post("/pharse/editPharse/{id}","PharseController:editPharse");
$app->get("/pharse/getPharseById/{id}","PharseController:getPharseById");
$app->get("/pharse/openProject/{id}","PharseController:openProject");
//============================================================+
// End Pharse Routes
//============================================================





//============================================================+
// Start Task Routes
//============================================================
$app->post("/task/registerTask","TaskController:registerTask");
$app->get("/task/getTasks","TaskController:getTasks");
$app->post("/task/deleteTask/{id}","TaskController:deleteTask");
$app->post("/task/editTask/{id}","TaskController:editTask");
$app->get("/task/getTaskById/{id}","TaskController:getTaskById");
$app->get("/task/openProject/{id}","TaskController:openProject");
$app->get("/task/overdueTask/{id}","TaskController:overdueTask");
$app->get("/task/openUpdates/{id}","TaskController:openUpdates");
//============================================================+
// End Task Routes
//============================================================




//============================================================+
// Start Task Routes
//============================================================
$app->post("/cost/registerCost","CostController:registerCost");
$app->get("/cost/getCosts","CostController:getCosts");
$app->post("/cost/deleteCost/{id}","CostController:deleteCost");
$app->post("/cost/editCost/{id}","CostController:editCost");
$app->get("/cost/getCostById/{id}","CostController:getCostById");
$app->get("/cost/openProject/{id}","CostController:openProject");
//============================================================+
// End Task Routes
//============================================================




//============================================================+
// Start Events Routes
//============================================================
$app->post("/event/registerEvent","EventController:registerEvent");
$app->get("/event/getEvents","EventController:getEvents");
$app->post("/event/deleteEvent/{id}","EventController:deleteEvent");
$app->post("/event/editEvent/{id}","EventController:editEvent");
$app->get("/event/getEventById/{id}","EventController:getEventById");
//============================================================+
// End Events Routes
//============================================================



//============================================================+
// Start Feedback Routes
//============================================================
$app->post("/feedback/registerFeedback","FeedbackController:registerFeedback");
$app->get("/feedback/getFeedbacks","FeedbackController:getFeedbacks");
$app->post("/feedback/deleteFeedback/{id}","FeedbackController:deleteFeedback");
$app->post("/feedback/editFeedback/{id}","FeedbackController:editFeedback");
$app->get("/feedback/getFeedbackById/{id}","FeedbackController:getFeedbackById");
//============================================================+
// End Feedback Routes
//===========================================================




?>
