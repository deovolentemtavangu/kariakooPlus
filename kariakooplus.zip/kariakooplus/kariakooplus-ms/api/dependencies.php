<?php
 
  //-------------------------------------------------------------------------
  // get app Container 
  //-------------------------------------------------------------------------
   $container=$app->getContainer();
  
 
  //-------------------------------------------------------------------------
  // illuminate Settings
  //-------------------------------------------------------------------------
    $capsule = new \Illuminate\Database\Capsule\Manager;
    $capsule->addConnection($container['settings']['db']);

    $capsule->setAsGlobal();
    $capsule->bootEloquent();
     

  //-------------------------------------------------------------------------
  // assigning db to container
  //-------------------------------------------------------------------------

    $container['db']=function ($container) use ($capsule){
        return $capsule;
    };

    //-------------------------------------------------------------------------
    // Callling Validator  constructor 
    //-------------------------------------------------------------------------

    $container['Validator']=function($container){
        return new \Api\Validation\Validator;
    };
     
    $container['StaffController']=function($container){
    return new \Api\Controllers\StaffController($container);
    };

         
    $container['UserController']=function($container){
    return new \Api\Controllers\UserController($container);
    };


    $container['ProjectController']=function($container){
    return new \Api\Controllers\ProjectController($container);
    };

    $container['PharseController']=function($container){
    return new \Api\Controllers\PharseController($container);
    };

    $container['TaskController']=function($container){
    return new \Api\Controllers\TaskController($container);
    };

    $container['CostController']=function($container){
    return new \Api\Controllers\CostController($container);
    };

    $container['EventController']=function($container){
    return new \Api\Controllers\EventController($container);
    };

 

 








