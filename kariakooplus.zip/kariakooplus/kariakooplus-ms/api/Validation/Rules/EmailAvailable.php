<?php

/**
* 
*/
namespace Api\Validation\Rules;

use Respect\Validation\Rules\AbstractRule;
use Api\Models\Users;
class EmailAvailable extends AbstractRule
{
	
	 public function validate($input){
	  	$data=Users::where("author","davi")->count();
      if($data==0){

          echo "ok $input";
           return false;
      }else{
          echo "no $input";
          return true;
      }
     
     
	 }

}
?>