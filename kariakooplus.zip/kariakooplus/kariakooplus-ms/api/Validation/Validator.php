<?php
/**
* 
*/
namespace Api\Validation;
use Respect\Validation\Validator as Respect;
use Respect\Validation\Exceptions\NestedValidationException;
class Validator 
{
	 protected $errors;
	 public function validate($request,array $rules){
	 	try{
                foreach ($rules as $field => $rule) {
          	    $rule->setName($field)->assert($request->getParam($field)); 
                }
	 	}catch(NestedValidationException $e){
               
               foreach ($e->getMessages()  as $value) {
               	   $this->errors['error']=$value;
               }
	 	}
            return $this;
	 }

	 public function validation(){
	 	return !empty($this->errors);
	 }
	 public function getValidationErrors(){
	 	return $this->errors;
	 }
}
?>