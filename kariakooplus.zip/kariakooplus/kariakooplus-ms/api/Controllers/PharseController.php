<?php

namespace Api\Controllers;

use Respect\Validation\Validator as v;


class PharseController extends Controller{
 
    public function registerPharse($request,$response){
      $data = $request->getParams();
      $valid=$this->Validator->validate($request,[
        'project_id' =>v::notEmpty(),
        'pharse_name'=>v::notEmpty(),
        'department'=>v::notEmpty(),
        'status'=>v::notEmpty(),
        'department'=>v::notEmpty(),
        'accountable'=>v::notEmpty(),
        'start_date'=>v::notEmpty(),        
        'end_date'=>v::notEmpty(),  
      ]);
       
        if($valid->validation()){

        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');


        }else{

            $result=$this->db->table("project_pharse")->where("project_id",$data['project_id'])
            ->where("pharse_name",$data['pharse_name'])->get();


            if($result->isEmpty()){
             $pharseName = '';
            }

            else{
              $pharseName = $result->toArray()[0]->pharse_name;                         
              } 

            if($pharseName == $data['pharse_name']){
            $status = array("status"=>"failed","msg"=>"Pharse Already Exist");
              
            }



            else{           

            $fields=array(
                "project_id"=>(isset($data['project_id']))? $data['project_id'] : null,
                "pharse_name"=>(isset($data['pharse_name']))? $data['pharse_name'] : null,
                "status"=>(isset($data['status']))? $data['status'] : null,
                "department"=>(isset($data['department']))? $data['department'] : null,
                "accountable"=>(isset($data['accountable']))? $data['accountable'] : null,
                "start_date"=>(isset($data['start_date']))? $data['start_date'] : null,
                "end_date"=>(isset($data['end_date']))? $data['end_date'] : null,
                "created_at"=>date("Y-m-d H:i:s"),
                "updated_at"=>date("Y-m-d H:i:s"),
                "created_by"=>$data['created_by'],
            );          


          //Update complete task in project pharses
           if($data['status']=='Completed'){
            $this->db->table("project")->where('project_id', '=', $data['project_id'])
            ->increment('complete_pharse', 1);
            }            


          $result=$this->db->table("project_pharse")->insert($fields);
          if($result){

            $status =array("status"=>"success","msg"=>"Pharse added Successfully","fields"=>$fields);

          }else{
            $status =array("status"=>"failed","msg"=>"Pharse failed to be added","fields"=>$fields);
          }
        }
           $response->getBody()->write(json_encode($status));
           $response = $response->withHeader('Content-Type', 'application/json');
        }

        return $response;
    }

       public function editPharse($request,$response){
        $id = $request->getAttribute('id');
        $data = $request->getParams();
        $valid=$this->Validator->validate($request,[
          'status'=>v::notEmpty(),
          'start_date'=>v::notEmpty(),        
          'end_date'=>v::notEmpty(),  
        ]);
       
        if($valid->validation()){
        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');

        }else{
            
            $fields=array(
                "status"=>(isset($data['status']))? $data['status'] : null,
                "start_date"=>(isset($data['start_date']))? $data['start_date'] : null,
                "end_date"=>(isset($data['end_date']))? $data['end_date'] : null,
                "updated_at"=>date("Y-m-d H:i:s"),
            );

            $pharse = $this->db->table("project_pharse")->where("pharse_id",$id)->get(); 
            if(!$pharse){
             $status =array("status"=>"failed","msg"=>"Pharse Not found"); 
            }
            else{
             $status = $pharse->toArray()[0]->status;
             $project_id = $data['project_id'];

          // Update complete task in project pharses
           if($status!='Completed' && $data['status']=='Completed'){
            $this->db->table("project")->where('project_id', '=', $data['project_id'])
            ->increment('complet_pharse', 1);
            }

          // Update complete task in project pharses
           if($status=='Completed' && $data['status']!='Completed'){
            $this->db->table("project")->where('project_id', '=', $data['project_id'])
            ->decrement('complet_pharse', 1);
            }


          $result=$this->db->table("project_pharse")->where("pharse_id",$id)->update($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"Pharse Successfully Updated","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Pharse failed to be updated","fields"=>$fields);
          }
        }
         
          $response->getBody()->write(json_encode($status));
          $response = $response->withHeader('Content-Type', 'application/json');
        }

       
        return $response;
    }

    public function getPharses($request,$response){
     $result=$this->db->table("project_pharse")
      ->leftJoin('project', 'project_pharse.project_id', '=', 'project.project_id')     
      ->select('project.project_id', 'project.project_name','project_pharse.pharse_id',
      'project_pharse.pharse_name','project_pharse.start_date as startdate','project_pharse.end_date as enddate',
      'project_pharse.status as pharseStatus')
     ->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }


   public function openProject($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("project_pharse")->where("project_id",$id)->orderBy('pharse_id')->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }    

   public function getPharseById($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("project_pharse")
      ->leftJoin('project', 'project_pharse.project_id', '=', 'project.project_id')     
      ->select('project.project_id', 'project.project_name','project_pharse.pharse_id',
      'project_pharse.department','project_pharse.pharse_id','project_pharse.pharse_name','project_pharse.start_date',
      'project_pharse.end_date','project_pharse.status','project_pharse.created_at',
      'project_pharse.total_task','project_pharse.complete_task')     
     ->where("pharse_id",$id)->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }

   public function deletePharse($request,$response){
      $id = $request->getAttribute('id');

      $result=$this->db->table("project_pharse")->where("pharse_id",$id)->delete();
      if($result){
        $status =array("status"=>"success","msg"=>"Pharse Deleted Successfully","fields"=>$id);
      }else{
        $status =array("status"=>"failed","msg"=>"Pharse Failed to be Deleted","fields"=>$id);
      }
      $response->getBody()->write(json_encode($status));
      $response = $response->withHeader('Content-Type', 'application/json');
      return $response;
   }

}

?>