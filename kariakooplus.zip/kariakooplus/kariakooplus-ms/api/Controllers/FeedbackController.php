<?php

namespace Api\Controllers;

use Respect\Validation\Validator as v;
use \Firebase\JWT\JWT;


class FeedbackController extends Controller{
 
    public function registerFeedback($request,$response){
      $data = $request->getParams();
      $valid=$this->Validator->validate($request,[
        'feedback'=>v::notEmpty(),
        'email'=>v::notEmpty(),
      ]);
       
        if($valid->validation()){

        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');


        }else{


            $fields=array(
                "feedback"=>(isset($data['feedback']))? $data['feedback'] : null,
                "email"=>(isset($data['email']))? $data['email'] : null,
                "user_id"=>"1",
                "created_at"=>date("Y-m-d H:i:s"),
                "created_by"=>"system",
            );


          $result=$this->db->table("feedback_tb")->insert($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"You have registered Successfully","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Feedback failed to be registered","fields"=>$fields);
          }
           $response->getBody()->write(json_encode($status));
           $response = $response->withHeader('Content-Type', 'application/json');
        }

       
        return $response;
    }

       public function editFeedback($request,$response){
        $id = $request->getAttribute('id');
        $data = $request->getParams();
          $valid=$this->Validator->validate($request,[
            'feedback'=>v::notEmpty(),
            'email'=>v::notEmpty(),
          ]);

       
        if($valid->validation()){
        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');

        }

        else{

            $fields=array(
                "feedback"=>(isset($data['feedback']))? $data['feedback'] : null,
                "email"=>(isset($data['email']))? $data['email'] : null,
                "user_id"=>"1",
                "updated_at"=>date("Y-m-d H:i:s"),
                "updated_by"=>"system",
            );



          $result=$this->db->table("feedback_tb")->where("id",$id)->update($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"Feedback Successfully Updated","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Feedback failed to be updated","fields"=>$fields);
          }
         
          $response->getBody()->write(json_encode($status));
          $response = $response->withHeader('Content-Type', 'application/json');
        }

       
        return $response;
    }

    public function getFeedbacks($request,$response){
     $result=$this->db->table("feedback_tb")->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }

   public function getFeedbackById($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("feedback_tb")->where("id",$id)->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }


   public function deleteFeedback($request,$response){
      $id = $request->getAttribute('id');

      $result=$this->db->table("feedback_tb")->where("id",$id)->delete();
      if($result){
        $status =array("status"=>"success","msg"=>"Feedback Deleted Successfully","fields"=>$id);
      }else{
        $status =array("status"=>"failed","msg"=>"Feedback Failed to be Deleted","fields"=>$id);
      }
      $response->getBody()->write(json_encode($status));
      $response = $response->withHeader('Content-Type', 'application/json');
      return $response;
   }




}

?>