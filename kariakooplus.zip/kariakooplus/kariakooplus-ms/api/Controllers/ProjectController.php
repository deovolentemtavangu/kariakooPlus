<?php

namespace Api\Controllers;

use Respect\Validation\Validator as v;


class ProjectController extends Controller{
 
    public function registerProject($request,$response){
      $data = $request->getParams();
      $valid=$this->Validator->validate($request,[
        'project_name'=>v::notEmpty(),
        'description'=>v::notEmpty(),
        'start_date'=>v::notEmpty(),        
        'end_date'=>v::notEmpty(),  
      ]);
       
        if($valid->validation()){

        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');
        }
        
        else{
           
            $fields=array(
                "project_name"=>(isset($data['project_name']))? $data['project_name'] : null,
                "description"=>(isset($data['description']))? $data['description'] : null,
                "start_date"=>(isset($data['start_date']))? $data['start_date'] : null,
                "end_date"=>(isset($data['end_date']))? $data['end_date'] : null,
                "created_at"=>date("Y-m-d H:i:s"),
                "updated_at"=>date("Y-m-d H:i:s"),
                "created_by"=>$data['created_by'],
            );


          $result=$this->db->table("project")->insert($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"Project added Successfully","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Project failed to be added","fields"=>$fields);
          }
           $response->getBody()->write(json_encode($status));
           $response = $response->withHeader('Content-Type', 'application/json');
        }

        return $response;
    }

       public function editProject($request,$response){
        $id = $request->getAttribute('id');
        $data = $request->getParams();
        $valid=$this->Validator->validate($request,[
          'project_name'=>v::notEmpty(),
          'description'=>v::notEmpty(),
          'start_date'=>v::notEmpty(),        
          'end_date'=>v::notEmpty(),  
        ]);

       
        if($valid->validation()){
        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');

        }else{

            $fields=array(
                "project_name"=>(isset($data['project_name']))? $data['project_name'] : null,
                "description"=>(isset($data['description']))? $data['description'] : null,
                "start_date"=>(isset($data['start_date']))? $data['start_date'] : null,
                "end_date"=>(isset($data['end_date']))? $data['end_date'] : null,
                "updated_at"=>date("Y-m-d H:i:s"),
            );


          $result=$this->db->table("project")->where("project_id",$id)->update($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"Project Successfully Updated","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Project failed to be updated","fields"=>$fields);
          }
         
          $response->getBody()->write(json_encode($status));
          $response = $response->withHeader('Content-Type', 'application/json');
        }

       
        return $response;
    }

    public function getProjects($request,$response){
     $result=$this->db->table("project")->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }

   public function getProjectById($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("project")->where("project_id",$id)->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }  


   public function deleteProject($request,$response){
      $id = $request->getAttribute('id');

      $result=$this->db->table("project")->where("project_id",$id)->delete();
      if($result){
        $status =array("status"=>"success","msg"=>"Project Deleted Successfully","fields"=>$id);

        $this->db->table("project_pharse")->where("project_id",$id)->delete();
        $this->db->table("project_task")->where("project",$id)->delete();
        $this->db->table("project_cost")->where("project_id",$id)->delete();

      }else{
        $status =array("status"=>"failed","msg"=>"Project Failed to be Deleted","fields"=>$id);
      }
      $response->getBody()->write(json_encode($status));
      $response = $response->withHeader('Content-Type', 'application/json');
      return $response;
   }

}

?>