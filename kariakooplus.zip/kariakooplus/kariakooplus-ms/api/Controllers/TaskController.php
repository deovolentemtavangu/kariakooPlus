<?php

namespace Api\Controllers;

use Respect\Validation\Validator as v;


class TaskController extends Controller{

    public function registerTask($request,$response){
      $data = $request->getParams();
      
      $valid=$this->Validator->validate($request,[
        'task_name'=>v::notEmpty(),
        'pharse' =>v::notEmpty(),
        'project' =>v::notEmpty(),
        'status'=>v::notEmpty(),
        'category'=>v::notEmpty(),
        'accountable'=>v::notEmpty(),
        'start_date'=>v::notEmpty(),        
        'end_date'=>v::notEmpty(),  
      ]);
       
        if($valid->validation()){
        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');

        }else{
        $pharse_id = $data['pharse'];
  
           
            $fields=array(
                "pharse_id"=>$pharse_id,
                "project"=>(isset($data['project']))? $data['project'] : null,
                "task_name"=>(isset($data['task_name']))? $data['task_name'] : null,
                "status"=>(isset($data['status']))? $data['status'] : null,
                "category"=>(isset($data['category']))? $data['category'] : null,
                "accountable"=>(isset($data['accountable']))? $data['accountable'] : null,
                "start_date"=>(isset($data['start_date']))? $data['start_date'] : null,
                "end_date"=>(isset($data['end_date']))? $data['end_date'] : null,
                "created_at"=>date("Y-m-d H:i:s"),
                "updated_at"=>date("Y-m-d H:i:s"),
                "created_by"=>$data['created_by'],
            );

            $this->db->table("project_pharse")->where('pharse_id', '=', $pharse_id)
            ->increment('total_task', 1);


          //Update complete task in project pharses
           if($data['status']=='Completed'){
            $this->db->table("project_pharse")->where('pharse_id', '=', $pharse_id)
            ->increment('complete_task', 1);
            }



          $result=$this->db->table("project_task")->insert($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"Task added Successfully","fields"=>$fields); 

          }else{
            $status =array("status"=>"failed","msg"=>"Task failed to be added","fields"=>$fields);
          }
        
           $response->getBody()->write(json_encode($status));
           $response = $response->withHeader('Content-Type', 'application/json');
        }

        return $response;
    }

       public function editTask($request,$response){
        $id = $request->getAttribute('id');
        $data = $request->getParams();
        $valid=$this->Validator->validate($request,[
          'task_name'=>v::notEmpty(),
          'status'=>v::notEmpty(),
          'start_date'=>v::notEmpty(),        
          'end_date'=>v::notEmpty(),  
        ]);
       
        if($valid->validation()){
        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');

        }

        else{

            $fields=array(
                "task_name"=>(isset($data['task_name']))? $data['task_name'] : null,
                "status"=>(isset($data['status']))? $data['status'] : null,
                "start_date"=>(isset($data['start_date']))? $data['start_date'] : null,
                "end_date"=>(isset($data['end_date']))? $data['end_date'] : null,
                "updated_at"=>date("Y-m-d H:i:s"),
            );

          $task = $this->db->table("project_task")->where("task_id",$id)->get(); 
          if($task->isEmpty()){
           $status =array("status"=>"failed","msg"=>"Task Not found"); 
          }
          else{
           $status = $task->toArray()[0]->status;
           $pharse_id = $task->toArray()[0]->pharse_id;

          // Update complete task in project pharses
           if($status!='Completed' && $data['status']=='Completed'){
            $this->db->table("project_pharse")->where('pharse_id', '=', $pharse_id)
            ->increment('complete_task', 1);

            }

          // Update complete task in project pharses
           if($status=='Completed' && $data['status']!='Completed'){
            $this->db->table("project_pharse")->where('pharse_id', '=', $pharse_id)
            ->decrement('complete_task', 1);
            }

          // Update pharse status if all task have been completed in that pharse........
          $check_if_pharse_completed = $this->db->table("project_pharse")->where("pharse_id",$pharse_id)->get();

          $totaltask = $check_if_pharse_completed->toArray()[0]->total_task;
          $completetask = $check_if_pharse_completed->toArray()[0]->complete_task;

          if($totaltask==$completetask){

            $status=array("status"=>'Completed');
            $this->db->table("project_pharse")->where("pharse_id",$pharse_id)->update($status);
          }



          $result=$this->db->table("project_task")->where("task_id",$id)->update($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"Task Successfully Updated","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Task failed to be updated","fields"=>$fields);
          }
        }
         
          $response->getBody()->write(json_encode($status));
          $response = $response->withHeader('Content-Type', 'application/json');
        }
       
        return $response;
    }

    public function getTasks($request,$response){
     $result=$this->db->table("project_task")->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }



/* 
      ->select('project_pharse.project_id','project_pharse.pharse_id',
      'project_task.task_name','project_task.start_date','project_task.end_date',
      'project_task.status','project_task.description')
*/


   public function openProject($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("project_task")
      ->leftJoin('project_pharse', 'project_pharse.pharse_id', '=', 'project_task.pharse_id')
      ->leftJoin('staff', 'staff.staff_id', '=', 'project_task.accountable')
      ->select('project_pharse.project_id','project_pharse.pharse_id','project_pharse.pharse_name',
      'project_task.task_name','project_task.task_id','project_task.start_date','project_task.end_date',
      'project_task.status','project_task.description','project_task.accountable','staff.first_name',
      'staff.last_name')                
      ->where("project_id", $id)
      ->where("category", 'Project')->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   } 



   public function openUpdates($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("project_task")
      ->leftJoin('project_pharse', 'project_pharse.pharse_id', '=', 'project_task.pharse_id')
      ->leftJoin('staff', 'staff.staff_id', '=', 'project_task.accountable')
      ->select('project_pharse.project_id','project_pharse.pharse_id','project_pharse.pharse_name',
      'project_task.task_name','project_task.task_id','project_task.start_date','project_task.end_date',
      'project_task.status','project_task.description','project_task.accountable','staff.first_name',
      'staff.last_name')                
      ->where("project_id", $id)
      ->where("category", 'Updates')->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }  


   public function overdueTask($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("project_task")
      ->leftJoin('project_pharse', 'project_pharse.pharse_id', '=', 'project_task.pharse_id')
      ->leftJoin('staff', 'staff.staff_id', '=', 'project_task.task_id')
      ->select('project_pharse.project_id','project_pharse.pharse_id','project_pharse.pharse_name',
      'project_task.task_name','project_task.start_date','project_task.end_date',
      'project_task.status','project_task.description','project_task.accountable','staff.first_name',
      'staff.last_name')                
      ->where("project_id",$id)
      ->where("project_task.end_date", '<', date("Y-m-d"))
      ->where("project_task.status", '!=', 'Completed')
      ->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   } 




   public function getTaskById($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("project_task")->where("task_id",$id)->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }

   public function deleteTask($request,$response){
      $id = $request->getAttribute('id');


      $task = $this->db->table("project_task")->where("task_id",$id)->get(); 
      if($task->isEmpty()){
      $status =array("status"=>"failed","msg"=>"Task Not found"); 
      }
      else{
      $status = $task->toArray()[0]->status;
      $pharse_id = $task->toArray()[0]->pharse_id;
      $complete_task = $this->db->table("project_pharse")->where("pharse_id",$pharse_id)->get();

      if($status == 'Completed'){
      $this->db->table("project_pharse")->where('pharse_id', '=', $pharse_id)
      ->decrement('complete_task', 1);

      $this->db->table("project_pharse")->where('pharse_id', '=', $pharse_id)
      ->decrement('total_task', 1);
      }

      else{
      $this->db->table("project_pharse")->where('pharse_id', '=', $pharse_id)
      ->decrement('total_task', 1);
      }

      $result=$this->db->table("project_task")->where("task_id",$id)->delete();
      if($result){
        $status =array("status"=>"success","msg"=>"Task Deleted Successfully","fields"=>$id);
      }else{
        $status =array("status"=>"failed","msg"=>"Task Failed to be Deleted","fields"=>$id);
      }
    }
      $response->getBody()->write(json_encode($status));
      $response = $response->withHeader('Content-Type', 'application/json');
      return $response;
   }

}

?>