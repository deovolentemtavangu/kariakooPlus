<?php

namespace Api\Controllers;

use Respect\Validation\Validator as v;


class CostController extends Controller {

    public function registerCost($request,$response){
      $data = $request->getParams();
      
      $valid=$this->Validator->validate($request,[
        'description'=>v::notEmpty(),
        'pharse' =>v::notEmpty(),
        'project' =>v::notEmpty(),
        'budgeted_cost'=>v::notEmpty(),
        'actual_cost'=>v::notEmpty(),  
      ]);
       
        if($valid->validation()){
        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');

        }else{
  
           
            $fields=array(
                "project_id"=>(isset($data['project']))? $data['project'] : null,
                "description"=>(isset($data['description']))? $data['description'] : null,
                "pharse"=>(isset($data['pharse']))? $data['pharse'] : null,
                "budgeted_cost"=>(isset($data['budgeted_cost']))? $data['budgeted_cost'] : null,
                "actual_cost"=>(isset($data['actual_cost']))? $data['actual_cost'] : null,
                "created_at"=>date("Y-m-d H:i:s"),
                "created_by"=>$data['created_by'],
            );

            $result=$this->db->table("project")->where("project_id",$data['project'])->get();
            $budgeted_cost = $result->toArray()[0]->budgeted_cost;
            $actual_cost = $result->toArray()[0]->actual_cost;            

            $project_field=array(
                "budgeted_cost"=>$budgeted_cost+$data['budgeted_cost'],
                "actual_cost"=>$actual_cost+$data['actual_cost'],
            );            



          $result=$this->db->table("project_cost")->insert($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"Cost added Successfully","fields"=>$fields);

           $this->db->table("project")->where("project_id",$data['project'])->update($project_field);  

          }else{
            $status =array("status"=>"failed","msg"=>"Cost failed to be added","fields"=>$fields);
          }
        
           $response->getBody()->write(json_encode($status));
           $response = $response->withHeader('Content-Type', 'application/json');
        }

        return $response;
    }

       public function editCost($request,$response){
        $id = $request->getAttribute('id');
        $data = $request->getParams();
        $valid=$this->Validator->validate($request,[
          'description'=>v::notEmpty(),
          'pharse' =>v::notEmpty(),
          'budgeted_cost'=>v::notEmpty(),
          'actual_cost'=>v::notEmpty(),  
        ]);
       
        if($valid->validation()){
        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');

        }

        else{

            $fields=array(
                "description"=>(isset($data['description']))? $data['description'] : null,
                "pharse"=>(isset($data['pharse']))? $data['pharse'] : null,
                "budgeted_cost"=>(isset($data['budgeted_cost']))? $data['budgeted_cost'] : null,
                "actual_cost"=>(isset($data['actual_cost']))? $data['actual_cost'] : null,
                "updated_at"=>date("Y-m-d H:i:s"),
            );

            $result=$this->db->table("project")->where("project_id",$data['project'])->get();
            if($result->isEmpty()){
            $status =array("status"=>"failed","msg"=>"Project not found","fields");
            }

            else{
            
            // Get total project cost
            $db_budgeted_cost = $result->toArray()[0]->budgeted_cost;
            $db_actual_cost = $result->toArray()[0]->actual_cost;            
            
            // Get old  project cost  to be updated
            $result=$this->db->table("project_cost")->where("id",$id)->get();
            if($result->isEmpty()){
            $status =array("status"=>"failed","msg"=>"Cost not found");
            }

            else{

            $old_budgeted_cost = $result->toArray()[0]->budgeted_cost;
            $old_actual_cost = $result->toArray()[0]->actual_cost;

            $new_budgeted_cost = $db_budgeted_cost-$old_budgeted_cost;
            $new_actual_cost =  $db_actual_cost-$old_actual_cost;

            
            // Update project cost  
            $update_project_cost=array(
            "budgeted_cost"=> $new_budgeted_cost+$data['budgeted_cost'],
            "actual_cost"=>$new_actual_cost+$data['actual_cost'],
            ); 



          $result=$this->db->table("project_cost")->where("id",$id)->update($fields);
          if($result){

            $status =array("status"=>"success","msg"=>"Cost Successfully Updated","fields"=>$fields);
            $this->db->table("project")->where("project_id",$data['project'])->update($update_project_cost);

          }else{
            $status =array("status"=>"failed","msg"=>"Cost failed to be updated","fields"=>$fields);
          }
        }
      }
        
         
          $response->getBody()->write(json_encode($status));
          $response = $response->withHeader('Content-Type', 'application/json');
        }
       
        return $response;
    }

    public function getCosts($request,$response){
     $result=$this->db->table("project_cost")
     ->leftJoin('project', 'project.project_id', '=', 'project_cost.project_id')
     ->select('project.project_id','project.project_name','project_cost.id','project_cost.description',
     'project_cost.pharse','project_cost.actual_cost','project_cost.budgeted_cost')
     ->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }




   public function getCostById($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("project_cost")
     ->leftJoin('project', 'project.project_id', '=', 'project_cost.project_id')
     ->select('project.project_id','project.project_name','project_cost.id','project_cost.description',
     'project_cost.pharse','project_cost.actual_cost','project_cost.budgeted_cost')     
     ->where("id",$id)->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }


   public function openProject($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("project_cost")
     ->leftJoin('project', 'project.project_id', '=', 'project_cost.project_id')
     ->select('project.project_id','project.project_name','project_cost.id','project_cost.description',
     'project_cost.pharse','project_cost.actual_cost','project_cost.budgeted_cost')     
     ->where("project.project_id",$id)->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }






   public function deleteCost($request,$response){
      $id = $request->getAttribute('id');

      $result=$this->db->table("project_cost")->where("id",$id)->delete();
      if($result){
        $status =array("status"=>"success","msg"=>"Cost Deleted Successfully","fields"=>$id);
      }else{
        $status =array("status"=>"failed","msg"=>"Cost Failed to be Deleted","fields"=>$id);
      }
      $response->getBody()->write(json_encode($status));
      $response = $response->withHeader('Content-Type', 'application/json');
      return $response;
   }

}

?>