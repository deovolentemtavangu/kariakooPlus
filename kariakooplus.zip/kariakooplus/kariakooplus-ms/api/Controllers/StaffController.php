<?php

namespace Api\Controllers;

use Respect\Validation\Validator as v;
use \Firebase\JWT\JWT;


class StaffController extends Controller{
 
    public function registerStaff($request,$response){
      $data = $request->getParams();
      $valid=$this->Validator->validate($request,[
        'first_name'=>v::notEmpty(),
        'last_name'=>v::notEmpty(),
        'phone_number'=>v::notEmpty(),
        'position'=>v::notEmpty(),        
        'email'=>v::notEmpty(), 
        'password'=>v::notEmpty(),
        'gender'=>v::notEmpty(), 
      ]);
       
        if($valid->validation()){

        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');


        }else{

         $hash_password = password_hash($data['password'], PASSWORD_DEFAULT);

            $fields=array(
                "first_name"=>(isset($data['first_name']))? $data['first_name'] : null,
                "last_name"=>(isset($data['last_name']))? $data['last_name'] : null,
                "email"=>(isset($data['email']))? $data['email'] : null,
                "position"=>(isset($data['position']))? $data['position'] : null,
                "phone_number"=>(isset($data['phone_number']))? $data['phone_number'] : null,
                "gender"=>(isset($data['gender']))? $data['gender'] : null,
                "password"=>(isset($hash_password))? $hash_password : null,
                "created_at"=>date("Y-m-d H:i:s"),
                "updated_at"=>date("Y-m-d H:i:s"),
                "created_by"=>$data['created_by'],
            );


          $result=$this->db->table("staff")->insert($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"You have registered Successfully","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Staff failed to be registered","fields"=>$fields);
          }
           $response->getBody()->write(json_encode($status));
           $response = $response->withHeader('Content-Type', 'application/json');
        }

       
        return $response;
    }

       public function editStaff($request,$response){
        $id = $request->getAttribute('id');
        $data = $request->getParams();
          $valid=$this->Validator->validate($request,[
            'first_name'=>v::notEmpty(),
            'last_name'=>v::notEmpty(),
            'phone_number'=>v::notEmpty(),
            'position'=>v::notEmpty(),        
            'email'=>v::notEmpty(), 
            'gender'=>v::notEmpty(), 
          ]);
       
        if($valid->validation()){
        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');

        }else{

            $fields=array(
                "first_name"=>(isset($data['first_name']))? $data['first_name'] : null,
                "last_name"=>(isset($data['last_name']))? $data['last_name'] : null,
                "position"=>(isset($data['position']))? $data['position'] : null,
                "email"=>(isset($data['email']))? $data['email'] : null,
                "phone_number"=>(isset($data['phone_number']))? $data['phone_number'] : null,
                "gender"=>(isset($data['gender']))? $data['gender'] : null,
                "updated_at"=>date("Y-m-d H:i:s"),
            );


          $result=$this->db->table("staff")->where("staff_id",$id)->update($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"Staff Successfully Updated","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Staff failed to be updated","fields"=>$fields);
          }
         
          $response->getBody()->write(json_encode($status));
          $response = $response->withHeader('Content-Type', 'application/json');
        }

       
        return $response;
    }

    public function getStaffs($request,$response){
     $result=$this->db->table("staff")->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }

   public function getStaffById($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("staff")->where("staff_id",$id)->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }


   public function deleteStaff($request,$response){
      $id = $request->getAttribute('id');

      $result=$this->db->table("staff")->where("staff_id",$id)->delete();
      if($result){
        $status =array("status"=>"success","msg"=>"Staff Deleted Successfully","fields"=>$id);
      }else{
        $status =array("status"=>"failed","msg"=>"Staff Failed to be Deleted","fields"=>$id);
      }
      $response->getBody()->write(json_encode($status));
      $response = $response->withHeader('Content-Type', 'application/json');
      return $response;
   }


   public function authenticateUser($request,$response){
      $data = $request->getParams();
      $header = $request->getHeader("HTTP_AUTHORIZATION");
      $valid=$this->Validator->validate($request,[
        'email'=>v::notEmpty(),
        'password'=>v::notEmpty(),
      ]);
       
    if($valid->validation()){
    $response->getBody()->write(json_encode($valid->getValidationErrors()));
    $response = $response->withStatus(200)->withHeader('Content-Type', 'application/json');

    }else{
     

     $username=$this->db->table("staff")->where("email",$data['email'])->first();

     if($username != null){

      if(password_verify($data['password'], $username->password)){ 

      $id=$this->db->table("staff")->where("email",$data['email'])->value("staff_id");
      $email=$this->db->table("staff")->where("email",$data['email'])->value("email");
      $fname=$this->db->table("staff")->where("email",$data['email'])->value("first_name");
      $lname=$this->db->table("staff")->where("email",$data['email'])->value("last_name");
      $position=$this->db->table("staff")->where("email",$data['email'])->value("position");

      $key = "pandukifichomagufulimkapapandupanduani";
      $token = array(
          "id"=>$id,
          "email"=>$email,
          "fname"=>$fname,
          "lname"=>$lname,
          "position"=>$position,
          "email"=>$data['email'],
          "iss" => "http://example.org",
          "aud" => "http://example.com",
          "iat" => 1356999524,
          "nbf" => 1357000000
      );
     

      $jwt = JWT::encode($token, $key);
      //$decoded = JWT::decode($token, $key, array('HS256'));
      $status =array("status"=>"success","msg"=>"Login Successfully","token"=>$jwt);
      $response->getBody()->write(json_encode($status));
      $response = $response->withStatus(200)->withHeader('Content-Type', 'application/json');

      }

      else {
      $status =array("status"=>"failed","msg"=>"Invalid password");
      $response->getBody()->write(json_encode($status));
      $response = $response->withStatus(200)->withHeader('Content-Type', 'application/json');    
      }

     }

     else{
      $status =array("status"=>"failed","msg"=>"Invalid username");
      $response->getBody()->write(json_encode($status));
      $response = $response->withStatus(200)->withHeader('Content-Type', 'application/json');
     }
   
     
     
   }
   return $response;

  }  


  public function getTokenData($request,$response){
      $data = $request->getParams();

      $valid=$this->Validator->validate($request,[
        'token'=>v::notEmpty(),
         
      ]);
       
    if($valid->validation()){

    $response->getBody()->write(json_encode($valid->getValidationErrors()));
    $response = $response->withStatus(400)->withHeader('Content-Type', 'application/json');
     

    }else{
     
     $key = "pandukifichomagufulimkapapandupanduani";
     $decoded = JWT::decode($data["token"], $key, array('HS256'));
     if($decoded){
     
      //$jwt = JWT::encode($token, $key);
     
      $status =array("status"=>"success","msg"=>"Verification Successfully","token_data"=>$decoded);
      $response->getBody()->write(json_encode($status));
      $response = $response->withStatus(200)->withHeader('Content-Type', 'application/json');
     }else{
      $status =array("status"=>"failed","msg"=>"Failed to verify");
      $response->getBody()->write(json_encode($status));
      $response = $response->withStatus(400)->withHeader('Content-Type', 'application/json');
     }
   
     
     
   }
   return $response;

  }

}

?>