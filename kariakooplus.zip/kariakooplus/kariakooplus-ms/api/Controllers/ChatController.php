<?php

namespace Api\Controllers;

use Respect\Validation\Validator as v;
use \Firebase\JWT\JWT;


class ChatController extends Controller{
 
    public function registerChat($request,$response){
      $data = $request->getParams();
      $valid=$this->Validator->validate($request,[
        'title'=>v::notEmpty(),
        'content'=>v::notEmpty(),
        'sender'=>v::notEmpty(),
        'receiver'=>v::notEmpty(),
      ]);
       
        if($valid->validation()){

        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');


        }else{


            $fields=array(
                "title"=>(isset($data['title']))? $data['title'] : null,
                "content"=>(isset($data['content']))? $data['content'] : null,
                "sender"=>(isset($data['sender']))? $data['sender'] : null,
                "receiver"=>(isset($data['receiver']))? $data['receiver'] : null,
                "created_at"=>date("Y-m-d H:i:s"),
                "created_by"=>"system",
            );


          $result=$this->db->table("chat_tb")->insert($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"You have registered Successfully","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Chat failed to be registered","fields"=>$fields);
          }
           $response->getBody()->write(json_encode($status));
           $response = $response->withHeader('Content-Type', 'application/json');
        }

       
        return $response;
    }

       public function editChat($request,$response){
        $id = $request->getAttribute('id');
        $data = $request->getParams();
          $valid=$this->Validator->validate($request,[
            'title'=>v::notEmpty(),
            'content'=>v::notEmpty(),
            'sender'=>v::notEmpty(),
            'receiver'=>v::notEmpty(),
          ]);

       
        if($valid->validation()){
        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');

        }else{

            $fields=array(
                "title"=>(isset($data['title']))? $data['title'] : null,
                "content"=>(isset($data['content']))? $data['content'] : null,
                "sender"=>(isset($data['sender']))? $data['sender'] : null,
                "receiver"=>(isset($data['receiver']))? $data['receiver'] : null,
                "updated_at"=>date("Y-m-d H:i:s"),
                "updated_by"=>"system",
            );


          $result=$this->db->table("chat_tb")->where("id",$id)->update($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"Chat Successfully Updated","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Chat failed to be updated","fields"=>$fields);
          }
         
          $response->getBody()->write(json_encode($status));
          $response = $response->withHeader('Content-Type', 'application/json');
        }

       
        return $response;
    }

    public function getChats($request,$response){
     $result=$this->db->table("chat_tb")->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }

   public function getChatById($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("chat_tb")->where("id",$id)->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }


   public function deleteFeedback($request,$response){
      $id = $request->getAttribute('id');

      $result=$this->db->table("chat_tb")->where("id",$id)->delete();
      if($result){
        $status =array("status"=>"success","msg"=>"Chat Deleted Successfully","fields"=>$id);
      }else{
        $status =array("status"=>"failed","msg"=>"Chat Failed to be Deleted","fields"=>$id);
      }
      $response->getBody()->write(json_encode($status));
      $response = $response->withHeader('Content-Type', 'application/json');
      return $response;
   }




}

?>