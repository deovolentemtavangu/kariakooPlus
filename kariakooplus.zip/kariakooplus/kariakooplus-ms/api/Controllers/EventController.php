<?php

namespace Api\Controllers;

use Respect\Validation\Validator as v;
use \Firebase\JWT\JWT;


class EventController extends Controller{
 
    public function registerEvent($request,$response){
      $data = $request->getParams();
      $valid=$this->Validator->validate($request,[
        'title'=>v::notEmpty(),
        'startdate'=>v::notEmpty(),
        'enddate'=>v::notEmpty(),
        'color'=>v::notEmpty(),
      ]);
       
        if($valid->validation()){

        $response->getBody()->write(json_encode($valid->getValidationErrors()));
        $response = $response->withHeader('Content-Type', 'application/json');


        }else{

            $color = "#".$data['color'];
            $fields=array(
                "title"=>(isset($data['title']))? $data['title'] : null,
                "startdate"=>(isset($data['startdate']))? $data['startdate'] : null,
                "enddate"=>(isset($data['enddate']))? $data['enddate'] : null,
                "color"=>$color,
                "created_at"=>date("Y-m-d H:i:s"),
            );


          $result=$this->db->table("events")->insert($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"You have registered Successfully","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Event failed to be registered","fields"=>$fields);
          }
           $response->getBody()->write(json_encode($status));
           $response = $response->withHeader('Content-Type', 'application/json');
        }

       
        return $response;
    }

       public function editEvent($request,$response){
            $data = $request->getParams();
            $id = $request->getAttribute('id');
            $fields=array(
                "startdate"=>(isset($data['startdate']))? $data['startdate'] : null,
                "enddate"=>(isset($data['enddate']))? $data['enddate'] : null,
                "updated_at"=>date("Y-m-d H:i:s"),
            );


          $result=$this->db->table("events")->where("id",$id)->update($fields);
          if($result){
            $status =array("status"=>"success","msg"=>"Event Successfully Updated","fields"=>$fields);
          }else{
            $status =array("status"=>"failed","msg"=>"Event failed to be updated","fields"=>$fields);
          }
         
          $response->getBody()->write(json_encode($status));
          $response = $response->withHeader('Content-Type', 'application/json');
        

       
        return $response;
    }

    public function getEvents($request,$response){
     $result=$this->db->table("events")
     ->select('id','title','startdate as start','enddate as end','color')
     ->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }

   public function getStaffById($request,$response){
     $id = $request->getAttribute('id');
     $result=$this->db->table("events")->where("id",$id)->get();
     $response->getBody()->write(json_encode($result));
     $response = $response->withHeader('Content-Type', 'application/json');
     return $response;
   }


   public function deleteStaff($request,$response){
      $id = $request->getAttribute('id');

      $result=$this->db->table("events")->where("id",$id)->delete();
      if($result){
        $status =array("status"=>"success","msg"=>"Event Deleted Successfully","fields"=>$id);
      }else{
        $status =array("status"=>"failed","msg"=>"Event Failed to be Deleted","fields"=>$id);
      }
      $response->getBody()->write(json_encode($status));
      $response = $response->withHeader('Content-Type', 'application/json');
      return $response;
   }


}

?>