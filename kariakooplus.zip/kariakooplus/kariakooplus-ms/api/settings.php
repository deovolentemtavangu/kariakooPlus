<?php
return  ['settings' => [

        'determineRouteBeforeAppMiddleware' => false,
        'displayErrorDetails' => true,
        'db' => [
            
            // Eloquent configuration
                'driver' => 'mysql',
                'host' => 'localhost',
                'database' => 'kariakoo',
                'username' => 'root',
                'password' => '',
                'charset' => 'utf8',
                'collation' => 'utf8_unicode_ci',
                'prefix' => '',

        ]
    ]];



