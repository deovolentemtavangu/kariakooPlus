<?php

namespace Api\Middleware;
use Firebase\JWT\JWT;

class AuthMiddleware extends Middleware
{

    public function __invoke($request, $response, $next)
    {

        // Check if header has authorization
        if(!$request->hasHeader('authorization')) {
          $status =array("status"=>"failed","msg"=>"No Token");
          $response->getBody()->write(json_encode($status));
          return $response->withStatus(400)->withHeader('Content-Type', 'application/json');      
        }

         // Get token from authorization header
         $authHeader = $request->getHeader('authorization');
         $token = list($userJwt) = sscanf($authHeader[0], 'Bearer %s');

         // Decode token
         $key = "pandukifichomagufulimkapapandupanduani";
         $decoded = JWT::decode($token[0], $key, array('HS256'));
         
         if($decoded){

          $status =array("status"=>"success","msg"=>"Verification Successfully","token_data"=>$decoded);
          $response->getBody()->write(json_encode($status));
          $response = $response->withStatus(200)->withHeader('Content-Type', 'application/json');
         }

         else
            
         {
          $status =array("status"=>"failed","msg"=>"Failed to verify");
          $response->getBody()->write(json_encode($status));
          return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
         }



        $response = $next($request, $response);
        return $response;
    }
}

?>