  <!-- BEGIN: Head-->
    <?php require_once("includes/header-calendar.php");?>
    <!-- END: Header-->


    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
         
        <div class="col s12">
          <div class="container">
            <!-- Full Calendar -->

            <div id="app-calendar">

                <div class="row">
                     
                    <div class="col s12">
                        <div class="card">
                            <div class="card-content">
                                <h4 class="card-title">
                                    <b>CALENDAR</b>
                                </h4>
                                <div class="row">
                                    <div class="col m3">
                                        <div id='external-events'>
                                            <P>Draggable Events</P>
                                            <div class="fc-events-container">
                                                <div class='fc-event' data-color='#009688'>Management Meeting</div>
                                                <div class='fc-event' data-color='#4CAF50'>Board Meeting</div>
                                                <div class='fc-event' data-color='#00bcd4'>Business Development Meeting</div>
                                                <div class='fc-event' data-color='#ff5722'>Project Management Meering</div>
                                                <div class='fc-event' data-color='#3f51b5'>Staff Meeting</div>
                                                <div class='fc-event' data-color='#9c27b0'>Financial Management</div>
                                                <div class='fc-event' data-color='#e51c23'>Project Deployment</div>
                                                <div class='fc-event' data-color='#e91e63'>Project Presentation</div>
                                                <div class='fc-event' data-color='#ffc107'>Seminar</div>
                                                <div class='fc-event' data-color='#4a148c'>Tranning</div>
                                                <p>
                                                    <label>
                                                        <input id="drop-remove" type="checkbox" />
                                                        <span>Remove After Drop</span>
                                                    </label>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col m9">
                                        <div id='fc-external-drag'></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    
     <!-- BEGIN: Footer-->
    <?php require_once("includes/footer-calendar.php"); ?>


    <script  type="text/javascript">
 
 /*
* Calendar
*/

$(document).ready(function () {
    "use strict";

    /* *********************
     * Draggble Calendar      *
     * ********************/

    $('#fc-external-drag').fullCalendar({
        header: {
              left: 'prev,next',
              center: 'title', 
              right: 'month,agendaWeek,agendaDay,listMonth'            
        },
        editable: true,
        droppable: true,
        dropAccept: '.fc-event',
        events: <?php echo file_get_contents("http://50.116.46.162/magilatech-ms/event/getEvents"); ?>,
        drop: function (date) {

        //Call when you drop any red/green/blue class to the week table.....first time runs only.....
        console.log("dropped");
        console.log(date.format());
        console.log(); // use the element's text as the event title
        console.log();
        var defaultDuration = moment.duration($('#calendar').fullCalendar('option', 'defaultTimedEventDuration'));
        var end = date.clone().add(defaultDuration); // on drop we only have date given to us
        console.log('end is ' + end.format());

        // POST TO DB.........
        var title =  $(this).text();
        var startdate = date.format();
        var enddate = end.format();
        var color = $(this).data('color');

        color =  (color.substring(1, color.length));


        var settings = {
         "async": true,
         "crossDomain": true,
         "url": "http://50.116.46.162/magilatech-ms/event/registerEvent?title="+title+
         "&startdate="+startdate+
         "&enddate="+enddate+
         "&color="+color+"",
         "method": "POST",
         "headers": {
           "cache-control": "no-cache",
           "postman-token": "b3b239b4-08de-ecee-8e6b-6441ede4a23a"
         }
        }

            $.ajax(settings).done(function (response) {
             console.log(response);
             if(response.error){
              Swal.fire(
                  'Error Found ?',
                  response.error+ color,
                  'error'
                );}
              
            else {

                if(response.status == "failed")
            {
              Swal.fire(
                  'Error Found ?',
                  response.msg,
                  'error'
                );}

            else if(response.status=="success"){
                Swal.fire(
                     'Success!',
                      response.msg,
                     'success'
                 )}
            }
                //$(".card-content").html(response.msg);
            });

    },

   

      eventDrop: function(event, delta, revertFunc, jsEvent, ui, view) {
        var getId = event.id;
        var startDate = event.start.format();
        var endDate = event.start.format();



        var settings = {
         "async": true,
         "crossDomain": true,
         "url": "http://50.116.46.162/magilatech-ms/event/editEvent/"+getId+"?startdate="+startDate+
         "&enddate="+endDate+"",
         "method": "POST",
         "headers": {
           "cache-control": "no-cache",
           "postman-token": "b3b239b4-08de-ecee-8e6b-6441ede4a23a"
         }
        }

            $.ajax(settings).done(function (response) {
             console.log(response);
             if(response.error){
              Swal.fire(
                  'Error Found ?',
                  response.error+ color,
                  'error'
                );}
              
            else {

                if(response.status == "failed")
            {
              Swal.fire(
                  'Error Found ?',
                  response.msg,
                  'error'
                );}

            else if(response.status=="success"){
                Swal.fire(
                     'Success!',
                      response.msg,
                     'success'
                 )}
            }
                //$(".card-content").html(response.msg);
            });
            // end of post........



      },



      /*  eventClick: function(calEvent, jsEvent, view) {
            $('#calendar').fullCalendar('removeEvents', function (event) {
                return event == calEvent;
            });
        }, */

       /* eventDragStop: function(event,jsEvent) {

            var trashEl = jQuery('#drop-remove');
            var ofs = trashEl.offset();

            var x1 = ofs.left;
            var x2 = ofs.left + trashEl.outerWidth(true);
            var y1 = ofs.top;
            var y2 = ofs.top + trashEl.outerHeight(true);

            if (jsEvent.pageX >= x1 && jsEvent.pageX<= x2 &&
                jsEvent.pageY >= y1 && jsEvent.pageY <= y2) {
                alert('SIII');

                //$('#calendario').fullCalendar('removeEvents', event.id);
            }
        }, */


        eventResize: function(event, delta, revertFunc, jsEvent, ui, view) {
        var getId = event.id;
        var startDate = event.start.format();
        var endDate = event.end.format();  

        var settings = {
         "async": true,
         "crossDomain": true,
         "url": "http://50.116.46.162/magilatech-ms/event/editEvent/"+getId+"?startdate="+startDate+
         "&enddate="+endDate+"",
         "method": "POST",
         "headers": {
           "cache-control": "no-cache",
           "postman-token": "b3b239b4-08de-ecee-8e6b-6441ede4a23a"
         }
        }

            $.ajax(settings).done(function (response) {
             console.log(response);
             if(response.error){
              Swal.fire(
                  'Error Found ?',
                  response.error+ color,
                  'error'
                );}
              
            else {

                if(response.status == "failed")
            {
              Swal.fire(
                  'Error Found ?',
                  response.msg,
                  'error'
                );}

            else if(response.status=="success"){
                Swal.fire(
                     'Success!',
                      response.msg,
                     'success'
                 )}
            }
                //$(".card-content").html(response.msg);
            });
            // end of post........


        }      


    })

    $('#external-events .fc-event').each(function () {

        // Different colors for events
        $(this).css({ 'backgroundColor': $(this).data('color'), 'borderColor': $(this).data('color') });

        // store data so the calendar knows to render an event upon drop
        $(this).data('event', {
            title: $.trim($(this).text()), // use the element's text as the event title
            color: $(this).data('color'),
            stick: true // maintain when user navigates (see docs on the renderEvent method)
        });

        // make the event draggable using jQuery UI
        $(this).draggable({
            zIndex: 999,
            revert: true,      // will cause the event to go back to its
            revertDuration: 0  //  original position after the drag
        });

    });





})       
</script>


    <!-- END: Footer-->