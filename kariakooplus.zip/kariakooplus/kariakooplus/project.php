<!-- BEGIN: Head-->
<?php require_once("includes/header.php");?>
<!-- END: Header-->
<!-- BEGIN: SideNav-->
<?php require_once("includes/sidebar.php"); ?>
<!-- END: SideNav-->
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->

      <div class="container">
        <div class="row">
          <div class="col s10 m6 l6 breadcrumbs-left">
            <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">PROJECTS
            </h5>
          </div>
        </div>
      </div>

    </div>
    <div class="content-wrapper-before blue-grey lighten-5">
    </div>
    <div class="col s12">
      <div class="container">
        <div class="row">
          <div class="col s12 m12 l12">
            <div class="card subscriber-list-card animate fadeRight">
              <div class="card-content pb-1">
                <h4 class="card-title mb-0">
                  <a href="registerProject.php" class="waves-effect waves-light btn gradient-45deg-red-pink z-depth-4 mr-1 mb-2">New
                  </a>
                </h4>
              </div>
              <table class="subscription-table responsive-table highlight">
                <thead>
                  <tr>
                    <th>S/No
                    </th>
                    <th>Project name
                    </th>
                    <th>Start Date
                    </th>
                    <th>Days
                    </th>                    
                    <th>Dedline
                    </th>
                    <th>Budget
                    </th>
                    <th>Actual Cost
                    </th>                    
                    <th>Progress
                    </th>

                    <th>Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                     $data = file_get_contents(BACKEND."project/getProjects");
                     $results = json_decode($data,true);
                     $index = 1;
                     foreach ($results as  $kw) {

                        if($kw['total_pharse']==0){
                        $progress =0;
                        $uncomplete_task = 100-$progress;

                        }

                        else{
                        $progress = $kw['complete_pharse']/$kw['total_pharse']*100;
                        $progress = round($progress,2);
                      }

                       $timeleft = strtotime($kw['end_date'])-strtotime(date("Y-m-d"));

                       $leftday=round((($timeleft/24)/60)/60);
                      

                       if($leftday<1){
                        $leftdays = '<span class="task-cat red accent-2">'.abs($leftday).' Days due</span>';
                       }

                       else{
                        $leftdays = '<span class="task-cat cyan">'.$leftday.' Days left</span>'
                        ;      
                       }


                  ?>
                  <tr pid="<?php echo $kw['project_id']; ?>">
                    <td>
                      <?php echo  $index; ?>
                    </td>
                    <td>
                      <?php echo (isset($kw["project_name"]))? $kw["project_name"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["start_date"]))? $kw["start_date"] : ""?>
                    </td>
                    <td>
                       <?php echo $leftdays ?>
                    </td>
                    <td>
                      <?php echo (isset($kw["end_date"]))? $kw["end_date"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["budgeted_cost"]))? $kw["budgeted_cost"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["actual_cost"]))? $kw["actual_cost"] : ""?>
                    </td>                    
                    <td>
                     <div class="progress">
                        <div class="determinate" style="width: <?php echo $progress ?>%"></div>
                     </div>
                     <div class="col s2"><span class="task-cat cyan"><?php echo $progress ?>%</span></div>
                    </td>                    
                    <td>
                       <ul id="<?php echo  $kw['project_id'].$kw['project_name'];?>" class='dropdown-content'>
                       <li><a href="viewProject.php?id=<?php echo  $kw['project_id'];?>">View</a></li>
                       <li><a href="updateProject.php?id=<?php echo  $kw['project_id'];?>">Update</a></li>
                       <li class="divider"></li>
                       <li><a href="Javascript:deleteProject(<?php echo $kw['project_id'];?>)">Delete</a></li>
                       </ul>
                       <a class='dropdown-trigger' href='#' data-target="<?php echo  $kw['project_id'].$kw['project_name'];?>">
                        <i class="material-icons pink-text">more_vert
                        </i>
                       </a>
                       <!-- Dropdown Structure -->                       
                    </td>
                  </tr>
                  <?php
                     $index++;
                     }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<!-- Theme Customizer -->
<!--/ Theme Customizer -->
<!-- BEGIN: Footer-->
<?php require_once("includes/footer.php"); ?>
<script  type="text/javascript">
function deleteProject(id){
Swal.fire({
  title: 'Are you sure ?',
  text: "You won't be able to recover this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {

    var settings = {
      "async": true,
      "crossDomain": true,
      "url":"http://localhost/magilatech-ms/project/deleteProject/"+id,
      "method": "POST",
      "headers": {
        "cache-control": "no-cache",
        "postman-token": "0820f20e-9bff-64c3-1b5b-9f115fc353cd"
      }
    }

    $.ajax(settings).done(function (response) {

      Swal.fire(
      'Deleted!',
       response.msg,
      'success'
      )
       $("tr#"+id+'').css("background-color",'#ccc');
       $("tr#"+id+'').fadeOut('slow');
      console.log(response);
    });

   
  }
})
}; 
</script>

<!-- END: Footer-->
