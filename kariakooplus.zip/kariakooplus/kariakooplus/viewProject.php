<!-- BEGIN: Head-->
<?php require_once("includes/header.php");?>
<!-- END: Header-->
<!-- BEGIN: SideNav-->
<?php require_once("includes/sidebar.php"); ?>
<!-- END: SideNav-->
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">

       <div class="row">
          <div class="col s12 m12 l12">
            <div class="card subscriber-list-card animate fadeRight">
              <div class="card-content pb-1">
                <h4 style="text-transform: uppercase;" class="card-title mb-0">Project:
                  <?php
                      if(isset($_GET['id'])){

                      $id=$_GET['id']; 
                    
                                   
                      $data = file_get_contents(BACKEND."project/getProjectById/$id");
                      $project_results = json_decode($data,true);

                      if(sizeof($project_results)>0){                  
                       echo $project_results[0]['project_name'];
                 }
                }
                ?>              
                </h4>
              </div>
            </div>
          </div>        
       </div>
<!--<div id="card-stats">

   <div class="row">
      <div class="col s12 m12 l12">
        <div class="card subscriber-list-card animate fadeRight">
            <div class="padding-4">

          <div class="col s3 m3">
            <p>Requirement</p>                   
              <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">
                <i class="material-icons gradient-45deg-green-teal white-text  background-round mt-5">check</i>
            </h5>
            <p>Complete</p>                
               </div>

               <div class="col s3 m3">
            <p>Designing</p>                   
              <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">
                <i class="material-icons gradient-45deg-green-teal white-text background-round mt-5">check</i>
            </h5>
            <p>Complete</p>                
               </div>

               <div class="col s3 m3">
            <p>Development</p>                
                  <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">
                    <a style="text-align: center; padding-top: 5px;" class= "btn-floating waves-effect btn-large  light-blue-cyan darken-4">60%
                    </a>
                  </h5>
                  <p>On Progress</p>                
               </div>

              <div class="col s3 m3">
            <p>Testing</p>                   
              <h5 class="">
                <i class="material-icons gradient-45deg-purple-deep-orange white-text background-round mt-5">alarm</i>
            </h5>
            <p>Waiting</p>                
               </div>
            </div>
        </div>
      </div>
   </div>
</div> -->
<!--card stats end-->


    </div>
    </div>
    <div class="content-wrapper-before blue-grey lighten-5">
    </div>
    <div class="col s12">
    <div class="container">

  <div class="row">
      <div class="col s12 m12 l12">
        <div class="card subscriber-list-card animate fadeRight">
          <div class="card-content pb-1">
            <h4 class="card-title mb-0">
              Overall Progress

          <div class="col s2 m6 l6 float-right"><a class="dropdown-settings waves-effect waves-light breadcrumbs-btn right" href="#!" data-target="dropdown1"><i class="material-icons right">more_vert</i></a>
            <ul class="dropdown-content" id="dropdown1" tabindex="0">
              <li tabindex="0"><a class="grey-text text-darken-2" href="registerPharse.php?id=<?php echo  $_GET['id'];?>">Add Pharse</a></li>
              <li tabindex="0"><a class="grey-text text-darken-2" href="registerTask.php?id=<?php echo  $_GET['id'];?>">
              Add Task</a></li>
              <li tabindex="0"><a class="grey-text text-darken-2" href="registerCost.php?id=<?php echo  $_GET['id'];?>">
              Add Cost</a></li>                  
              <li class="divider" tabindex="-1"></li>
              <li tabindex="0"><a class="grey-text text-darken-2" href="uploadFiles.php?id=<?php echo  $_GET['id'];?>">Attach File</a></li>
            </ul>
          </div>

              </h4>
          </div>
          <table class="responsive-table highlight">
            <thead>
              <tr>                  
                <th>Pharse
                </th>
                <th>Status
                </th>                                                           
                <th>Days
                </th> 
                <th>Health Status
                </th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php
                  if(isset($_GET['id'])){

                  $id=$_GET['id']; 
                
                               
                  $data = file_get_contents(BACKEND."pharse/openProject/$id");
                  $results = json_decode($data,true);

                  $index = 1;

                  foreach ($results as  $kw) {
                    
                    if($kw['total_task']==0){
                    $progress =0;
                    $uncomplete_task = 100-$progress;

                    }

                    else{
                    $progress = $kw['complete_task']/$kw['total_task']*100;
                    $uncomplete_task = 100-$progress;
                    }

                   $timeleft = strtotime($kw['end_date'])-strtotime(date("Y-m-d"));

                   $leftday=round((($timeleft/24)/60)/60);

                   if($leftday<1){
                    $leftdays = '<span class="task-cat gradient-45deg-red-pink accent-2">'.abs($leftday).' Days due</span>';
                   }

                   else{
                    $leftdays = '<span class="task-cat blue">'.$leftday.' Days left</span>'
                    ;      
                   }

                   if($kw['status']=='Waiting'){

                   $status = '<h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">
                    <i class="material-icons gradient-45deg-red-pink white-text background-round mt-5">update</i>
                    </h5>';
                   $pharse_progress = 
                   '<div class="progress">
                    <div class="determinate gradient-45deg-red-pink" style="width:'.$progress.'%"></div>
                    </div>
                    <div class="col s2"><span class="task-cat gradient-45deg-red-pink">'.$progress.'%</span>
                    </div>';  

                   }

                   if ($kw['status']=='On progress') {
                   $status = '<h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">
                    <i class="material-icons gradient-45deg-light-blue-cyan white-text background-round mt-5">network_check</i>
                    </h5>';
                  $pharse_progress = 
                   '<div class="progress">
                    <div class="determinate gradient-45deg-light-blue-cyan" style="width:'.$progress.'%"></div>
                    </div>
                    <div class="col s2"><span class="task-cat gradient-45deg-light-blue-cyan">
                    '.$progress.'%</span>
                    </div>';                    

                   }

                   if ($kw['status']=='Completed') {
                    
                    $status = '<h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">
                    <i class="material-icons gradient-45deg-green-teal white-text background-round mt-5">check</i>
                    </h5>';

                  $pharse_progress = 
                   '<div class="progress">
                    <div class="determinate  green" style="width: '.$progress.'%"></div>
                    </div>
                    <div class="col s2"><span class="task-cat green">'.$progress.'%</span>
                    </div>';                    
                   
                   $timeleft = strtotime($kw['end_date'])-strtotime($kw['start_date']);
                   $time = round((($timeleft/24)/60)/60);
                   $leftdays = '<span class="task-cat green">'.$time.' Days</span>';

                   }

                  ?>

              <tr id="<?php echo $kw['pharse_id']; ?>">
                <td>
                  <?php echo (isset($kw["pharse_name"]))? $kw["pharse_name"] : ""?>
                </td>

                <td>
                  <?php echo  $status; ?>

                  <?php echo (isset($kw["status"]))? $kw["status"] : ""?>
                </td>

                <td>
                  <?php echo $leftdays; ?>
                </td>

                <td>
                  <?php echo  $pharse_progress; ?>

                </td>

                <td>
                   <a class='dropdown-trigger'
                    href='#' data-target='<?php echo  $kw['pharse_id'].$kw["pharse_name"]; ?>'>
                    <i class="material-icons">more_vert
                    </i>
                   </a>
                   <!-- Dropdown Structure -->
                   <ul id='<?php echo  $kw['pharse_id'].$kw["pharse_name"]; ?>' class='dropdown-content'>
                   <li><a href="viewPharse.php?id=<?php echo  $kw['pharse_id'];?>">View</a></li>
                   <li><a href="updatePharse.php?id=<?php echo  $kw['pharse_id'];?>&staff=<?php echo  $kw['accountable'];?>">Update</a></li>
                   <li class="divider"></li>
                   <li><a href="Javascript:deletePharse(<?php echo $kw['pharse_id'] ; ?>)">Delete</a></li>
                   </ul>
                </td>

              </tr>
              <?php
                $index++;
                }
              ?>
            </tbody>
              <?php } ?>
          </table>
        </div>
      </div>    
    </div>       




<div class="row">
    <div class="col s12 m12 l12">
      <div class="card subscriber-list-card animate fadeRight">
        <div class="card-content pb-1">
          <h4 class="card-title mb-0">
            Project Task
          </h4>
        </div>
        <table class="subscription-table responsive-table highlight">
          <thead>
            <tr>
              <th>Task
              </th>
              <th>Pharse
              </th>                    
              <th>Status
              </th>                                                           
              <th>Days
              </th> 
              <th>Accountable
              </th>
              <td></td>                  
            </tr>
          </thead>
          <tbody>
            <?php
                if(isset($_GET['id'])){

                $id=$_GET['id']; 
              
                             
                $data = file_get_contents(BACKEND."task/openProject/$id");
                $results = json_decode($data,true);
                $index = 1;
                foreach ($results as  $kw) {

                 $timeleft = strtotime($kw['end_date'])-strtotime(date("Y-m-d"));

                 $leftday=round((($timeleft/24)/60)/60);

                 if(($kw["status"]!='Completed')&&(date("Y-m-d")>$kw['end_date'])){
                  $leftdays = '<span class="task-cat red accent-2">'.abs($leftday).' Days due</span>';
                 }

                 if(($kw["status"]!='Completed')&&(date("Y-m-d")<$kw['end_date'])){
                  $leftdays = '<span class="task-cat blue accent-2">'.abs($leftday).' Days left</span>';
                 }
              
                 else{

                 $timeleft = strtotime($kw['end_date'])-strtotime($kw['start_date']);
                 $leftday=round((($timeleft/24)/60)/60);

                  $leftdays = '<span class="task-cat green">'.$leftday.' Days</span>'
                  ;      
                 }

                ?>

            <tr>
              <td>
                <?php echo (isset($kw["task_name"]))? $kw["task_name"] : ""?>
              </td>

              <td>
                <?php echo (isset($kw["pharse_name"]))? $kw["pharse_name"] : ""?>
              </td>

              <td>
                <?php echo (isset($kw["status"]))? $kw["status"] : ""?>
              </td>

              <td>
                <?php echo $leftdays; ?>
              </td>

              <td>
                <?php echo  $kw["first_name"]. " ".$kw["first_name"]; ?>
              </td>

              <td>
                 <a class='dropdown-trigger'
                  href='#' data-target='<?php echo  $kw['task_id'].$kw["task_name"]; ?>'>
                  <i class="material-icons">more_vert
                  </i>
                 </a>
                 <!-- Dropdown Structure -->
                 <ul id='<?php echo  $kw['task_id'].$kw["task_name"]; ?>' class='dropdown-content'>
                 <li><a href="viewTask.php?id=<?php echo  $kw['task_id'];?>">View</a></li>
                 <li><a href="updateTask.php?id=<?php echo  $kw['task_id'];?>&project=<?php echo  $kw['project_id'];?>&pharse=<?php echo  $kw['pharse_id'];?>&staff=<?php echo  $kw['accountable'];?>">Update</a></li>
                 <li class="divider"></li>
                 <li><a href="Javascript:deleteTask(<?php echo $kw['task_id'] ; ?>)">Delete</a></li>
                 </ul>
              </td>


            </tr>
            <?php
              $index++;
              }
            ?>
          </tbody>
           <?php } ?>
        </table>
      </div>
    </div>    
  </div>



<div class="row">
    <div class="col s12 m12 l12">
      <div class="card subscriber-list-card animate fadeRight">
        <div class="card-content pb-1">
          <h4 class="card-title mb-0">
            Project Updates
          </h4>
        </div>
        <table class="subscription-table responsive-table highlight">
          <thead>
            <tr>
              <th>Task
              </th>
              <th>Pharse
              </th>                    
              <th>Status
              </th>                                                           
              <th>Days
              </th> 
              <th>Accountable
              </th>
              <td></td>                  
            </tr>
          </thead>
          <tbody>
            <?php
                if(isset($_GET['id'])){

                $id=$_GET['id']; 
              
                             
                $data = file_get_contents(BACKEND."task/openUpdates/$id");
                $results = json_decode($data,true);
                $index = 1;
                foreach ($results as  $kw) {

                 $timeleft = strtotime($kw['end_date'])-strtotime(date("Y-m-d"));

                 $leftday=round((($timeleft/24)/60)/60);

                 if(($kw["status"]!='Completed')&&(date("Y-m-d")>$kw['end_date'])){
                  $leftdays = '<span class="task-cat red accent-2">'.abs($leftday).' Days due</span>';
                 }

                 if(($kw["status"]!='Completed')&&(date("Y-m-d")<$kw['end_date'])){
                  $leftdays = '<span class="task-cat blue accent-2">'.abs($leftday).' Days left</span>';
                 }
              
                 else{

                 $timeleft = strtotime($kw['end_date'])-strtotime($kw['start_date']);
                 $leftday=round((($timeleft/24)/60)/60);

                  $leftdays = '<span class="task-cat green">'.$leftday.' Days</span>'
                  ;      
                 }

                ?>

            <tr>
              <td>
                <?php echo (isset($kw["task_name"]))? $kw["task_name"] : ""?>
              </td>

              <td>
                <?php echo (isset($kw["pharse_name"]))? $kw["pharse_name"] : ""?>
              </td>

              <td>
                <?php echo (isset($kw["status"]))? $kw["status"] : ""?>
              </td>

              <td>
                <?php echo $leftdays; ?>
              </td>

              <td>
                <?php echo  $kw["first_name"]. " ".$kw["first_name"]; ?>
              </td>

              <td>
                 <a class='dropdown-trigger'
                  href='#' data-target='<?php echo  $kw['task_id'].$kw["task_name"]; ?>'>
                  <i class="material-icons">more_vert
                  </i>
                 </a>
                 <!-- Dropdown Structure -->
                 <ul id='<?php echo  $kw['task_id'].$kw["task_name"]; ?>' class='dropdown-content'>
                 <li><a href="viewTask.php?id=<?php echo  $kw['task_id'];?>">View</a></li>
                 <li><a href="updateTask.php?id=<?php echo  $kw['task_id'];?>">Update</a></li>
                 <li class="divider"></li>
                 <li><a href="Javascript:deleteTask(<?php echo $kw['task_id'] ; ?>)">Delete</a></li>
                 </ul>
              </td>


            </tr>
            <?php
              $index++;
              }
            ?>
          </tbody>
           <?php } ?>
        </table>
      </div>
    </div>    
  </div>


<div class="row">
    <div class="col s12 m12 l12">
      <div class="card subscriber-list-card animate fadeRight">
        <div class="card-content pb-1">
          <h4 class="card-title mb-0">
            Cost
          </h4>
        </div>
        <table class="subscription-table responsive-table highlight">
          <thead>
            <tr>
              <th>Cost Description
              </th>
              <th>Pharse
              </th>                    
              <th>Budget
              </th>                                                           
              <th>Actual Cost
              </th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php
                if(isset($_GET['id'])){

                $id=$_GET['id']; 
              
                             
                $data = file_get_contents(BACKEND."cost/openProject/$id");
                $results = json_decode($data,true);
                $index = 1;
                foreach ($results as  $kw) {

                ?>

            <tr>
              <td>
                <?php echo (isset($kw["description"]))? $kw["description"] : ""?>
              </td>

              <td>
                <?php echo (isset($kw["pharse"]))? $kw["pharse"] : ""?>
              </td>

              <td>
                <?php echo (isset($kw["budgeted_cost"]))? $kw["budgeted_cost"] : ""?>
              </td>

              <td>
                <?php echo (isset($kw["actual_cost"]))? $kw["actual_cost"] : ""?>
              </td>

              <td>
                 <a class='dropdown-trigger'
                  href='#' data-target='<?php echo  $kw['id'].$kw["description"]; ?>'>
                  <i class="material-icons">more_vert
                  </i>
                 </a>
                 <!-- Dropdown Structure -->
                 <ul id='<?php echo  $kw['id'].$kw["description"]; ?>' class='dropdown-content'>
                 <li><a href="updateCost.php?id=<?php echo  $kw['id'];?>">Update</a></li>
                 <li class="divider"></li>
                 <li><a href="Javascript:deleteCost(<?php echo $kw['id'] ; ?>)">Delete</a></li>
                 </ul>
              </td>

            </tr>
            <?php
              $index++;
              }
            ?>
          </tbody>
           <?php } ?>
           <tfoot>
             <tr>
               <td><b>Total Cost</b></td>
               <td></td>
               <td><b><?php echo $project_results[0]['budgeted_cost']; ?></b></td>
               <td><b><?php echo $project_results[0]['actual_cost']; ?></b></td>
             </tr>
           </tfoot>
        </table>
      </div>
    </div>    
  </div> 



<div class="row">
 <!--chart dashboard start-->
  <div id="id="work-collections"">
      <div class="col s12 m12 l12">
         <ul id="projects-collection" class="collection z-depth-1 animate fadeLeft">
            <li class="collection-item avatar">
               <i class="material-icons cyan circle">card_travel</i>
               <h6 class="collection-header m-0">Overdue Task</h6>
            </li>


                  <?php
                      if(isset($_GET['id'])){

                      $id=$_GET['id']; 
                    
                                   
                      $data = file_get_contents(BACKEND."task/overdueTask/$id");
                      $results = json_decode($data,true);
                      $index = 1;
                      foreach ($results as  $kw) {

                       $timeleft = strtotime($kw['end_date'])-strtotime(date("Y-m-d"));

                       $leftday=round((($timeleft/24)/60)/60);

                      ?>


            <li class="collection-item">
               <div class="row">
                  <div class="col s6">
                     <p class="collections-title">Task: <?php echo  $kw["task_name"]; ?></p>
                     <p class="collections-content">Pharse: <?php echo  $kw["pharse_name"]; ?></p>
                  </div>
                  <div class="col s3">
                    <span class="task-cat gradient-45deg-red-pink">Over <?php echo abs($leftday); ?> Days</span>
                  <p class="collections-content">Accountable: <?php echo  $kw["first_name"] ." ".$kw["last_name"]; ?></p>
                  </div>
                  <div class="col s3">
                    <p class="collections-content">Start At: <?php echo  $kw["start_date"]; ?></p>
                    <p class="collections-content">Dedline: <?php echo  $kw["end_date"]; ?></p>
                     <div id="project-line-1"></div>
                  </div>
               </div>
            </li>

          <?php } ?>

         </ul>
      </div>
      <?php } ?>

</div>
<!--chart dashboard end-->  
</div>



      </div>
    </div>

  </div>
</div>
<!-- END: Page Main-->
<!-- Theme Customizer -->
<!--/ Theme Customizer -->
<!-- BEGIN: Footer-->
<?php require_once("includes/footer.php"); ?>
<script  type="text/javascript">
function deleteTask(id){
Swal.fire({
  title: 'Are you sure ?',
  text: "You won't be able to recover this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {

    var settings = {
      "async": true,
      "crossDomain": true,
      "url":"http://50.116.46.162/magilatech-ms/task/deleteTask/"+id,
      "method": "POST",
      "headers": {
        "cache-control": "no-cache",
        "postman-token": "0820f20e-9bff-64c3-1b5b-9f115fc353cd"
      }
    }

    $.ajax(settings).done(function (response) {

      Swal.fire(
      'Deleted!',
       response.msg,
      'success'
      )
       $("tr#"+id+'').css("background-color",'#ccc');
       $("tr#"+id+'').fadeOut('slow');
      console.log(response);
    });

   
  }
})
}; 
</script>

<script  type="text/javascript">
function deletePharse(id){
Swal.fire({
  title: 'Are you sure ?',
  text: "You won't be able to recover this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {

    var settings = {
      "async": true,
      "crossDomain": true,
      "url":"http://50.116.46.162/magilatech-ms/pharse/deletePharse/"+id,
      "method": "POST",
      "headers": {
        "cache-control": "no-cache",
        "postman-token": "0820f20e-9bff-64c3-1b5b-9f115fc353cd"
      }
    }

    $.ajax(settings).done(function (response) {

      Swal.fire(
      'Deleted!',
       response.msg,
      'success'
      )
       $("tr#"+id+'').css("background-color",'#ccc');
       $("tr#"+id+'').fadeOut('slow');
      console.log(response);
    });

   
  }
})
}; 
</script>

<!-- END: Footer-->
