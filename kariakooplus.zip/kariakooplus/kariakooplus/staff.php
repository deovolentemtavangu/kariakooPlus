<!-- BEGIN: Head-->
<?php require_once("includes/header.php");?>
<!-- END: Header-->
<!-- BEGIN: SideNav-->
<?php require_once("includes/sidebar.php"); ?>
<!-- END: SideNav-->
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">

      <div id="card-stats">
         <div class="row">
            <div class="col s12 m6 l6 xl3">
               <div class="card gradient-45deg-light-blue-cyan gradient-shadow min-height-100 white-text animate fadeLeft">
                  <div class="padding-4">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">add_shopping_cart</i>
                        <p>Total Staff</p>
                     </div>
                     <div class="col s5 m5 right-align">
                        <h5 class="mb-0 white-text">69</h5>
                        <p class="no-margin">Developer</p>
                        <p>500</p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col s12 m6 l6 xl3">
               <div class="card gradient-45deg-amber-amber gradient-shadow min-height-100 white-text animate fadeRight">
                  <div class="padding-4">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">timeline</i>
                        <p>New Staff</p>
                     </div>
                     <div class="col s5 m5 right-align">
                        <h5 class="mb-0 white-text">80%</h5>
                        <p class="no-margin">Operational</p>
                        <p>3</p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col s12 m6 l6 xl3">
               <div class="card gradient-45deg-red-pink gradient-shadow min-height-100 white-text animate fadeLeft">
                  <div class="padding-4">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">perm_identity</i>
                        <p>Female Staff</p>
                     </div>
                     <div class="col s5 m5 right-align">
                        <h5 class="mb-0 white-text">20</h5>
                        <p class="no-margin">Opeational</p>
                        <p>5</p>
                     </div>
                  </div>
               </div>
            </div>
           
            <div class="col s12 m6 l6 xl3">
               <div class="card gradient-45deg-green-teal gradient-shadow min-height-100 white-text animate fadeRight">
                  <div class="padding-4">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">attach_money</i>
                        <p>Male Staff</p>
                     </div>
                     <div class="col s5 m5 right-align">
                        <h5 class="mb-0 white-text">40</h5>
                        <p class="no-margin">Developers</p>
                        <p>600</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!--card stats end-->


      </div>
    </div>
    <div class="content-wrapper-before blue-grey lighten-5">
    </div>
    <div class="col s12">
      <div class="container">
        <div class="row">
          <div class="col s12 m12 l12">
            <div class="card subscriber-list-card animate fadeRight">
              <div class="card-content pb-1">
                <h4 class="card-title mb-0">
                  <a href="registerStaff.php" class="waves-effect waves-light btn gradient-45deg-red-pink z-depth-4 mr-1 mb-2">New
                  </a>
                </h4>
              </div>
              <table  id="page-length-option" class="subscription-table responsive-table highlight">
                <thead>
                  <tr>
                    <th>S/No
                    </th>
                    <th>First name
                    </th>
                    <th>Last name
                    </th>
                    <th>Position
                    </th>
                    <th>Gender
                    </th>
                    <th>Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $data = file_get_contents(BACKEND."user/getStaffs");
                  $results = json_decode($data,true);

                  $index = 1;
                  foreach ($results as  $kw) {
                  ?>
                  <tr id="<?php echo $kw['staff_id']; ?>">
                    <td>
                      <?php echo  $index; ?>
                    </td>
                    <td>
                      <?php echo (isset($kw["first_name"]))? $kw["first_name"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["last_name"]))? $kw["last_name"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["position"]))? $kw["position"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["gender"]))? $kw["gender"] : ""?>
                    </td>
                    <td >
                       <a class='dropdown-trigger'
                        href='#' data-target='<?php echo  $kw['staff_id'].$kw["first_name"]; ?>'>
                        <i class="material-icons pink-text">more_vert
                        </i>
                       </a>
                       <!-- Dropdown Structure -->
                       <ul id='<?php echo  $kw['staff_id'].$kw["first_name"]; ?>' class='dropdown-content'>
                       <li><a href="viewStaff.php?id=<?php echo  $kw['staff_id'];?>">View</a></li>
                       <li><a href="updateStaff.php?id=<?php echo  $kw['staff_id'];?>">Update</a></li>
                       <li class="divider"></li>
                       <li><a href="Javascript:deleteStaff(<?php echo $kw['staff_id'] ; ?>)">Delete</a></li>
                       </ul>
                    </td>
                  </tr>
                  <?php
                  $index++;
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<!-- Theme Customizer -->
<!--/ Theme Customizer -->
<!-- BEGIN: Footer-->
<?php require_once("includes/footer.php"); ?>
<script  type="text/javascript">

function deleteStaff(id){

Swal.fire({
  title: 'Are you sure ?',
  text: "You won't be able to recover this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {

    var settings = {
      "async": true,
      "crossDomain": true,
      "url":"http://50.116.46.162/magilatech-ms/user/deleteStaff/"+id,
      "method": "POST",
      "headers": {
        "cache-control": "no-cache",
        "postman-token": "0820f20e-9bff-64c3-1b5b-9f115fc353cd"
      }
    }

    $.ajax(settings).done(function (response) {

      Swal.fire(
      'Deleted!',
       response.msg,
      'success'
      )
       $("tr#"+id+'').css("background-color",'#ccc');
       $("tr#"+id+'').fadeOut('slow');
      console.log(response);
    });

   
  }
})
};  

</script>
<!-- END: Footer-->
