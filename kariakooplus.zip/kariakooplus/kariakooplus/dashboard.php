 <!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->


    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="content-wrapper-before blue-grey lighten-5"></div>
        <div class="col s12">
          <div class="container">
         <!--card stats start-->
         <?php
            $data = file_get_contents(BACKEND."dashbord/getTotals");
            $results = json_decode($data,true);
             ?>

          <div id="card-stats">
             <div class="row">
                <div class="col s12 m6 l6 xl3">
                   <div class="card gradient-45deg-light-blue-cyan gradient-shadow min-height-100 white-text animate fadeLeft">
                      <div class="padding-4">
                         <div class="col s7 m7">
                            <i class="material-icons background-round mt-5">business</i>
                            <p>Total Projects</p>
                         </div>
                         <div class="col s5 m5 right-align">
                            <h5 class="mb-0 white-text"><?php echo $results['project']; ?>
                            </h5>
                        </div>
                      </div>
                   </div>
                </div>
                <div class="col s12 m6 l6 xl3">
                   <div class="card gradient-45deg-amber-amber gradient-shadow min-height-100 white-text animate fadeRight">
                      <div class="padding-4">
                         <div class="col s9 m9">
                            <i class="material-icons background-round mt-5">today</i>
                            <p>Weekly Events</p>
                         </div>
                         <div class="col s3 m3 right-align">
                            <h5 class="mb-0 white-text"><?php echo $results['events']; ?></h5>
                         </div>
                      </div>
                   </div>
                </div>
                <div class="col s12 m6 l6 xl3">
                   <div class="card gradient-45deg-red-pink gradient-shadow min-height-100 white-text animate fadeLeft">
                      <div class="padding-4">
                         <div class="col s7 m7">
                            <i class="material-icons background-round mt-5">assignment</i>
                            <p>Weekly Task</p>
                         </div>
                         <div class="col s5 m5 right-align">
                            <h5 class="mb-0 white-text"><?php echo $results['task']; ?></h5>
                         </div>
                      </div>
                   </div>
                </div>
               
                <div class="col s12 m6 l6 xl3">
                   <div class="card gradient-45deg-green-teal gradient-shadow min-height-100 white-text animate fadeRight">
                      <div class="padding-4">
                         <div class="col s7 m7">
                            <i class="material-icons background-round mt-5">perm_identity</i>
                            <p>Total Staff</p>
                         </div>
                         <div class="col s5 m5 right-align">
                            <h5 class="mb-0 white-text"><?php echo $results['staff']; ?></h5>
                         </div>
                      </div>
                   </div>
                </div>
             </div>
          </div>
      <!--card stats end-->

<!--chart dashboard start-->
<div id="chart-dashboard">
   <div class="row">
      <div class="col s12 m12 l12">
         <div class="card animate fadeUp">
            <div class="card-move-up waves-effect waves-block waves-light">
               <div class="move-up cyan darken-1">
                  <div>
                     <span class="chart-title white-text">Task Overview</span>
                     <div class="chart-revenue cyan darken-2 white-text">
                      <ul class="doughnut-chart-legend">
                         <li class="blue lighten-3 ultra-small"><span class="legend-color-"></span>New task</li>
                         <li class="red ultra-small"><span class="legend-color"></span>Overdue task</li>
                         <li class="green ultra-small"><span class="legend-color"></span>Complete task</li>
                      </ul>
                     </div>
                     <div class="switch chart-revenue-switch right">
                        <label class="cyan-text text-lighten-5">
                        </label>
                     </div>
                  </div>
                  <div class="trending-line-chart-wrapper"><canvas id="revenue-line-chart" height="70"></canvas></div>
               </div>
            </div>
            <div class="card-content">
               <a class="btn-floating btn-move-up waves-effect waves-light red accent-2 z-depth-4 right">
                  <i class="material-icons activator">filter_list</i>
               </a>
               <div class="col s12 m3 l3">
                  <div id="doughnut-chart-wrapper">
                     <canvas id="doughnut-chart" height="200"></canvas>
                     <div class="doughnut-chart-status">
                        <p class="ultra-small center-align">Budget</p>
                     </div>
                  </div>
               </div>
               <div class="col s12 m2 l2">
                  <ul class="doughnut-chart-legend">
                     <li class="mobile ultra-small"><span class="legend-color"></span>Budget</li>
                     <li class="kitchen ultra-small"><span class="legend-color"></span> Actual</li>
                  </ul>
               </div>
               <div class="col s12 m5 l6">
                  <div class="trending-bar-chart-wrapper">
                     <canvas id="trending-bar-chart" height="90"></canvas>
                  </div>
               </div>
            </div>
            <div class="card-reveal">
               <span class="card-title grey-text text-darken-4">Monthly Tasks<i class="material-icons right">close</i>
               </span>
              <table  id="page-length-option" class="subscription-table responsive-table highlight">
                <thead>
                  <tr>
                    <th>S/No
                    </th>
                    <th>Task
                    </th>
                    <th>Project
                    </th>
                    <th>Status
                    </th>
                    <th>Accountable
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $data = file_get_contents(BACKEND."dashbord/monthlyTask");
                  $results = json_decode($data,true);

                  $index = 1;
                  foreach ($results as  $kw) {
                  ?>
                  <tr>
                    <td>
                      <?php echo  $index; ?>
                    </td>
                    <td>
                      <?php echo (isset($kw["task_name"]))? $kw["task_name"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["project_name"]))? $kw["project_name"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["status"]))? $kw["status"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["first_name"]))? $kw["first_name"] : ""?>
                    </td>
                  </tr>
                  <?php
                  $index++;
                  }
                  ?>
                </tbody>
              </table>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<!--chart dashboard end-->
 

<!--div class="row">

   <div class="col s12 m6 l8">
        <!-- Total Transaction -->
      <!--<div class="card">
         <div class="card-content">
            <h4 class="card-title mb-0">Total Project Profit <i class="material-icons float-right">more_vert</i></h4>
            <p class="medium-small">This profit transaction</p>
            <div class="total-transaction-container">
               <div id="total-transaction-line-chart" class="total-transaction-shadow"></div>
            </div>
         </div>
      </div>
    </div>

   <div class="col s12 m4 l4">
          <!-- Current Balance -->
      <!--<div class="card animate fadeLeft" style="padding-bottom: 50px">
         <div class="card-content">
            <h4 class="card-title mb-0">Total Project Cost  <i class="material-icons float-right">more_vert</i></h4>
            <p class="medium-small">This billing cycle</p>
            <div class="current-balance-container">
               <div id="current-balance-donut-chart" class="current-balance-shadow"></div>
            </div>
            <h5 class="center-align">$ 50,150.00</h5>
            <p class="medium-small center-align">Used balance this billing cycle</p>
         </div>
      </div>
   </div>
 </div> -->



<!--chart dashboard start-->
<div id="work-collections">
   <div class="col s12 m6 l6">
         <ul id="projects-collection" class="collection z-depth-1 animate fadeLeft">
            <li class="collection-item avatar">
               <i class="material-icons red circle">card_travel</i>
               <h6 class="collection-header m-0">Overdue Task</h6>
            </li>
                  <?php                    
                                   
                      $data = file_get_contents(BACKEND."dashbord/overdueTask");
                      $results = json_decode($data,true);
                      $index = 1;
                      foreach ($results as  $kw) {

                       $timeleft = strtotime($kw['end_date'])-strtotime(date("Y-m-d"));

                       $leftday=round((($timeleft/24)/60)/60);

                      ?>
                    <li class="collection-item">
                      <div class="row">
                        <div class="col s6">
                          <p class="collections-title">Task: <?php echo  $kw["task_name"]; ?></p>
                          <p class="collections-content">Project: <?php echo  $kw["project_name"]; ?></p>
                          <span class="task-cat gradient-45deg-red-pink">Over <?php echo abs($leftday); ?> Days</span>
                        </div>
                        <div class="col s6">
                          <p class="collections-content">Accountable: <?php echo  $kw["first_name"] ." ".$kw["last_name"]; ?></p>
                          <p class="collections-content">Start At: <?php echo  $kw["start_date"]; ?></p>
                          <p class="collections-content">Dedline: <?php echo  $kw["end_date"]; ?></p>

                     <div id="project-line-1"></div>
                  </div>
               </div>
            </li>

          <?php } ?>

         </ul>
       </div>

   <div class="col s12 m6 l6">
       <ul id="issues-collection" class="collection z-depth-1 animate fadeRight">
            <li class="collection-item avatar">
               <i class="material-icons cyan circle">bug_report</i>
               <h6 class="collection-header m-0">Upcoming</h6>
               <p>Dedlines</p>
             </li>
                  <?php                    
                                   
                      $data = file_get_contents(BACKEND."dashbord/upcomingDedline");
                      $results = json_decode($data,true);
                      $index = 1;
                      foreach ($results as  $kw) {

                       $timeleft = strtotime($kw['end_date'])-strtotime(date("Y-m-d"));

                       $leftday=round((($timeleft/24)/60)/60);

                      ?>
                    <li class="collection-item">
                      <div class="row">
                        <div class="col s6">
                          <p class="collections-title">Task: <?php echo  $kw["task_name"]; ?></p>
                          <p class="collections-content">Project: <?php echo  $kw["project_name"]; ?></p>
                          <span class="task-cat gradient-45deg-light-blue-cyan">Over <?php echo abs($leftday); ?> Days left</span>
                        </div>
                        <div class="col s6">
                          <p class="collections-content">Accountable: <?php echo  $kw["first_name"] ." ".$kw["last_name"]; ?></p>
                          <p class="collections-content">Start At: <?php echo  $kw["start_date"]; ?></p>
                          <p class="collections-content">Dedline: <?php echo  $kw["end_date"]; ?></p>

                     <div id="project-line-1"></div>
                  </div>
               </div>
            </li>

          <?php } ?>

         </ul>
       </div>
   </div>
</div>
<!--chart dashboard end-->

<!--Gradient Chart Card-->
  <!--<div id="card-gradient-chart" class="section">
            <div class="row">
                  <div class="col s12 m4 l4">
                        <div id="chartjs" class="card pt-0 pb-0">
                              <div class="padding-2 ml-2">
                                    <span class="new badge gradient-45deg-blue-indigo gradient-shadow mt-2 mr-2">+
                                          42</span>
                                    <p class="mt-2 mb-0 font-weight-600">Project Tasks</p>
                                    <p class="no-margin grey-text lighten-3">october 2019</p>
                                    <h5>35</h5>
                              </div>
                              <div class="row">
                                    <div class="sample-chart-wrapper card-gradient-chart">
                                          <canvas id="custom-line-chart-sample-one" class="center"></canvas>
                                    </div>
                              </div>
                        </div>
                  </div>
                  <div class="col s12 m4 l4">
                        <div id="chartjs2" class="card pt-0 pb-0">
                              <div class="padding-2 ml-2">
                                    <span class="new badge gradient-45deg-purple-deep-orange gradient-shadow mt-2 mr-2">+
                                          12</span>
                                    <p class="mt-2 mb-0 font-weight-600">Completed Task</p>
                                    <p class="no-margin grey-text lighten-3">october 2019</p>
                                    <h5>25</h5>
                              </div>
                              <div class="row">
                                    <div class="sample-chart-wrapper card-gradient-chart">
                                          <canvas id="custom-line-chart-sample-two" class="center"></canvas>
                                    </div>
                              </div>
                        </div>
                  </div>

                  <div class="col s12 m4 l4">
                        <div id="chartjs" class="card pt-0 pb-0">
                              <div class="padding-2 ml-2">
                                    <span class="new badge gradient-45deg-blue-indigo gradient-shadow mt-2 mr-2">+
                                          42</span>
                                    <p class="mt-2 mb-0 font-weight-600">Overdue Tasks</p>
                                    <p class="no-margin grey-text lighten-3">october 2019</p>
                                    <h5>5</h5>
                              </div>
                              <div class="row">
                                    <div class="sample-chart-wrapper card-gradient-chart">
                                          <canvas id="custom-line-chart-sample-one" class="center"></canvas>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
      </div>-->
   </div>
</div>
</div>
    <!-- END: Page Main-->

    <!-- Theme Customizer -->

    <!--/ Theme Customizer -->

 
   
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>
    <!-- END: Footer-->

<script type="text/javascript">
// Dashboard - Analytics
//----------------------

(function(window, document, $) {
   //Sample toast
 /*  setTimeout(function() {
      M.toast({ html: "Hey! I am a toast." });
   }, 2000);
*/
   //Trending line chart
   var revenueLineChartCTX = $("#revenue-line-chart");

   var revenueLineChartOptions = {
      responsive: true,
      // maintainAspectRatio: false,
      legend: {
         display: false
      },
      hover: {
         mode: "label"
      },
      scales: {
         xAxes: [
            {
               display: true,
               gridLines: {
                  display: false
               },
               ticks: {
                  fontColor: "#fff"
               }
            }
         ],
         yAxes: [
            {
               display: true,
               fontColor: "#fff",
               gridLines: {
                  display: true,
                  color: "rgba(255,255,255,0.3)"
               },
               ticks: {
                  beginAtZero: false,
                  fontColor: "#fff"
               }
            }
         ]
      }
   };

   var revenueLineChartData = {
      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      datasets: [
         {
            label: "New Task",
            data:<?php echo file_get_contents(BACKEND."dashbord/getNewTask"); ?>,
            backgroundColor: "rgba(128, 222, 234, 0.5)",
            borderColor: "#80deea",
            pointBorderColor: "#80deea",
            pointBackgroundColor: "#80deea",
            pointHighlightFill: "#80deea",
            pointHoverBackgroundColor: "#80deea",
            borderWidth: 2,
            pointBorderWidth: 2,
            pointHoverBorderWidth: 4,
            pointRadius: 4
         },
         {
            label: "Complete Task",
            data:<?php echo file_get_contents(BACKEND."dashbord/getCompletedTask"); ?>,
            borderDash: [5, 1],
            backgroundColor: "rgba(128, 222, 234, 0.2)",
            borderColor: "#4caf50",
            pointBorderColor: "#4caf50",
            pointBackgroundColor: "#4caf50",
            pointHighlightFill: "#4caf50",
            pointHoverBackgroundColor: "#4caf50",
            borderWidth: 2,
            pointBorderWidth: 2,
            pointHoverBorderWidth: 4,
            pointRadius: 4
         },

         {
            label: "Overdue Task",
            data:<?php echo file_get_contents(BACKEND."dashbord/getOverdueTask"); ?>,
            borderDash: [15, 5],
            backgroundColor: "rgba(128, 222, 234, 0.2)",
            borderColor: "#f44336",
            pointBorderColor: "#f44336",
            pointBackgroundColor: "#f44336",
            pointHighlightFill: "#f44336",
            pointHoverBackgroundColor: "#f44336",
            borderWidth: 2,
            pointBorderWidth: 2,
            pointHoverBorderWidth: 4,
            pointRadius: 4
         }

      ]
   };


   var revenueLineChartConfig = {
      type: "line",
      options: revenueLineChartOptions,
      data: revenueLineChartData
   };

   /*
Doughnut Chart Widget
*/

   var doughnutSalesChartCTX = $("#doughnut-chart");
   var browserStatsChartOptions = {
      cutoutPercentage: 70,
      legend: {
         display: false
      }
   };

   var doughnutSalesChartData = {
      labels: ["Monthly Budget", "Monthly Actual Cost"],
      datasets: [
         {
            label: "Budget",
            data: <?php echo file_get_contents(BACKEND."dashbord/getMonthlyCost"); ?>,
            backgroundColor: ["#F7464A", "#46BFBD"]
         }
      ]
   };

   var doughnutSalesChartConfig = {
      type: "doughnut",
      options: browserStatsChartOptions,
      data: doughnutSalesChartData
   };

   /*
Monthly Revenue : Trending Bar Chart
*/

   var monthlyRevenueChartCTX = $("#trending-bar-chart");
   var monthlyRevenueChartOptions = {
      responsive: true,
      // maintainAspectRatio: false,
      legend: {
         display: false
      },
      hover: {
         mode: "label"
      },
      scales: {
         xAxes: [
            {
               display: true,
               gridLines: {
                  display: false
               }
            }
         ],
         yAxes: [
            {
               display: true,
               fontColor: "#fff",
               gridLines: {
                  display: false
               },
               ticks: {
                  beginAtZero: true
               }
            }
         ]
      },
      tooltips: {
         titleFontSize: 0,
         callbacks: {
            label: function(tooltipItem, data) {
               return tooltipItem.yLabel;
            }
         }
      }
   };
   var monthlyRevenueChartData = {
      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      datasets: [
         {
            label: "Monhly Project",
            data: <?php echo file_get_contents(BACKEND."dashbord/getNewProject"); ?>,
            backgroundColor: "#46BFBD",
            hoverBackgroundColor: "#009688"
         }
      ]
   };

   var nReloads1 = 0;
   var min1 = 1;
   var max1 = 10;
   var monthlyRevenueChart;
   function updateMonthlyRevenueChart() {
      if (typeof monthlyRevenueChart != "undefined") {
         nReloads1++;
         var x = Math.floor(Math.random() * (max1 - min1 + 1)) + min1;
         monthlyRevenueChartData.datasets[0].data.shift();
         monthlyRevenueChartData.datasets[0].data.push([x]);
         monthlyRevenueChart.update();
      }
   }
   //setInterval(updateMonthlyRevenueChart, 2000);

   var monthlyRevenueChartConfig = {
      type: "bar",
      options: monthlyRevenueChartOptions,
      data: monthlyRevenueChartData
   };

   /*
Trending Bar Chart
*/

   var browserStatsChartCTX = $("#trending-radar-chart");

   var browserStatsChartOptions = {
      responsive: true,
      // maintainAspectRatio: false,
      legend: {
         display: false
      },
      hover: {
         mode: "label"
      },
      scale: {
         angleLines: { color: "rgba(255,255,255,0.4)" },
         gridLines: { color: "rgba(255,255,255,0.2)" },
         ticks: {
            display: false
         },
         pointLabels: {
            fontColor: "#fff"
         }
      }
   };

   var browserStatsChartData = {
      labels: ["Chrome", "Mozilla", "Safari", "IE10", "Opera"],
      datasets: [
         {
            label: "Browser",
            data: [5, 6, 7, 8, 6],
            fillColor: "rgba(255,255,255,0.2)",
            borderColor: "#fff",
            pointBorderColor: "#fff",
            pointBackgroundColor: "#00bfa5",
            pointHighlightFill: "#fff",
            pointHoverBackgroundColor: "#fff",
            borderWidth: 2,
            pointBorderWidth: 2,
            pointHoverBorderWidth: 4
         }
      ]
   };

   var nReloads2 = 0;
   var min2 = 1;
   var max2 = 10;
   var browserStatsChart;
   function browserStatsChartUpdate() {
      if (typeof browserStatsChart != "undefined") {
         nReloads2++;
         var x = Math.floor(Math.random() * (max2 - min2 + 1)) + min2;
         browserStatsChartData.datasets[0].data.pop();
         browserStatsChartData.datasets[0].data.push([x]);
         browserStatsChart.update();
      }
   }
   setInterval(browserStatsChartUpdate, 2000);

   var browserStatsChartConfig = {
      type: "radar",
      options: browserStatsChartOptions,
      data: browserStatsChartData
   };

   /*
   Revenue by country - Line Chart
*/

   var countryRevenueChartCTX = $("#line-chart");

   var countryRevenueChartOption = {
      responsive: true,
      // maintainAspectRatio: false,
      legend: {
         display: false
      },
      hover: {
         mode: "label"
      },
      scales: {
         xAxes: [
            {
               display: true,
               gridLines: {
                  display: false
               },
               ticks: {
                  fontColor: "#fff"
               }
            }
         ],
         yAxes: [
            {
               display: true,
               fontColor: "#fff",
               gridLines: {
                  display: false
               },
               ticks: {
                  beginAtZero: false,
                  fontColor: "#fff"
               }
            }
         ]
      }
   };

   var countryRevenueChartData = {
      labels: ["USA", "UK", "UAE", "AUS", "IN", "SA"],
      datasets: [
         {
            label: "Sales",
            data: [65, 45, 50, 30, 63, 45],
            fill: false,
            lineTension: 0,
            borderColor: "#fff",
            pointBorderColor: "#fff",
            pointBackgroundColor: "#009688",
            pointHighlightFill: "#fff",
            pointHoverBackgroundColor: "#fff",
            borderWidth: 2,
            pointBorderWidth: 2,
            pointHoverBorderWidth: 4,
            pointRadius: 4
         }
      ]
   };
   var countryRevenueChartConfig = {
      type: "line",
      options: countryRevenueChartOption,
      data: countryRevenueChartData
   };

   // Polar chart
   // ----------------
   //Get the context of the Chart canvas element we want to select
   var polarChartCTX = $("#polar-chart");

   // Chart Options
   var polarChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      responsiveAnimationDuration: 500,
      legend: {
         display: false
      },
      title: {
         display: false,
         text: "Chart.js Polar Area Chart"
      },
      scale: {
         pointLabels: {
            fontColor: "#fff"
         },
         ticks: {
            beginAtZero: true,
            display: false
         },
         reverse: false
      },
      animation: {
         animateRotate: false
      }
   };

   // Chart Data
   var polarChartData = {
      labels: ["USA", "UK", "Canada", "Austrelia", "India", "Brazil", "Germany"],
      datasets: [
         {
            data: [4800, 6000, 1800, 4000, 5500, 2100, 3500],
            backgroundColor: ["#f44336", "#9c27b0", "#3f51b5", "#2196f3", "#ff9800", "#009688", "#4caf50"],
            hoverBackgroundColor: ["#FF5A5E", "#ce93d8", "#7986cb", "#90caf9", "#ffb74d", "#80cbc4", "#81c784"],
            label: "My dataset" // for legend
         }
      ]
   };

   var polarChartConfig = {
      type: "polarArea",
      options: polarChartOptions,
      data: polarChartData
   };

   // Create the chart

   window.onload = function() {
      revenueLineChart = new Chart(revenueLineChartCTX, revenueLineChartConfig);
      monthlyRevenueChart = new Chart(monthlyRevenueChartCTX, monthlyRevenueChartConfig);
      var doughnutSalesChart = new Chart(doughnutSalesChartCTX, doughnutSalesChartConfig);
      browserStatsChart = new Chart(browserStatsChartCTX, browserStatsChartConfig);
      var countryRevenueChart = new Chart(countryRevenueChartCTX, countryRevenueChartConfig);
      polarChart = new Chart(polarChartCTX, polarChartConfig);
   };

   $(function() {
      /*
       * STATS CARDS
       */
      // Bar chart ( New Clients)
      $("#clients-bar").sparkline([70, 80, 65, 78, 58, 80, 78, 80, 70, 50, 75, 65, 80, 70, 65, 90, 65, 80, 70, 65, 90], {
         type: "bar",
         height: "25",
         barWidth: 7,
         barSpacing: 4,
         barColor: "#b2ebf2",
         negBarColor: "#81d4fa",
         zeroColor: "#81d4fa"
      });
      // Total Sales - Bar
      $("#sales-compositebar").sparkline([4, 6, 7, 7, 4, 3, 2, 3, 1, 4, 6, 5, 9, 4, 6, 7, 7, 4, 6, 5, 9], {
         type: "bar",
         barColor: "#F6CAFD",
         height: "25",
         width: "100%",
         barWidth: "7",
         barSpacing: 4
      });
      //Total Sales - Line
      $("#sales-compositebar").sparkline([4, 1, 5, 7, 9, 9, 8, 8, 4, 2, 5, 6, 7], {
         composite: true,
         type: "line",
         width: "100%",
         lineWidth: 2,
         lineColor: "#fff3e0",
         fillColor: "rgba(255, 82, 82, 0.25)",
         highlightSpotColor: "#fff3e0",
         highlightLineColor: "#fff3e0",
         minSpotColor: "#00bcd4",
         maxSpotColor: "#00e676",
         spotColor: "#fff3e0",
         spotRadius: 4
      });
      // Tristate chart (Today Profit)
      $("#profit-tristate").sparkline([2, 3, 0, 4, -5, -6, 7, -2, 3, 0, 2, 3, -1, 0, 2, 3, 3, -1, 0, 2, 3], {
         type: "tristate",
         width: "100%",
         height: "25",
         posBarColor: "#ffecb3",
         negBarColor: "#fff8e1",
         barWidth: 7,
         barSpacing: 4,
         zeroAxis: false
      });
      // Line chart ( New Invoice)
      $("#invoice-line").sparkline([5, 6, 7, 9, 9, 5, 3, 2, 2, 4, 6, 7, 5, 6, 7, 9, 9, 5], {
         type: "line",
         width: "100%",
         height: "25",
         lineWidth: 2,
         lineColor: "#E1D0FF",
         fillColor: "rgba(255, 255, 255, 0.2)",
         highlightSpotColor: "#E1D0FF",
         highlightLineColor: "#E1D0FF",
         minSpotColor: "#00bcd4",
         maxSpotColor: "#4caf50",
         spotColor: "#E1D0FF",
         spotRadius: 4
      });
   });
})(window, document, jQuery);
   
</script>