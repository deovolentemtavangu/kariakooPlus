    <!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">ADD COST</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">

  <div class="row">
    <!-- Form -->
    <div class="col s12 m12 l12">
      <div id="Form-advance" class="card card card-default scrollspy">
        <div class="card-content">
          <h4 class="card-title"></h4>
          <div class="col s12">

            <div class="row">
              <div class="input-field col m s12">
                  <i class="material-icons prefix">message</i>
                <label for="description">Cost Description</label>
                <input type="text" id="description">
              </div>
              </div>            

            <div class="row">
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">business</i>
                  <?php
                      if(isset($_GET['id'])){

                      $id=$_GET['id'];   
                      $data = file_get_contents(BACKEND."project/getProjectById/$id");
                      $results = json_decode($data,true);

                      if(sizeof($results)>0){                  
                       $project_name = $results[0]['project_name'];
                       $project_id = $results[0]['project_id'];
                      }
                      else {
                       $project_name = '';
                       $project_id = '';
                      }
                      
                  ?>
                    <input type="text" value='<?php echo $project_name ?>' disabled='true'>
                    <input type="hidden" id='project' value='<?php echo $project_id ?>'>
                  <?php } ?>
                <label for="project_id">Project</label>
              </div>

              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">filter_list</i>
                  <select id="pharse">
                  <option  value="All Pharses" selected>All Pharses</option>
                  <option value="Requirement">Requirement and Analysis</option>
                  <option value="Designing">Designing</option>
                  <option value="Development">Development</option>
                  <option value="Testing">Testing</option>
                  <option value="Deployment">Deployment</option>
                  <option value="Documentation">Documentation</option>
                </select>
                <label for="pharse_name">Pharse</label>
              </div>

            </div>
            <div class="row">
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">view_module</i>
                  <input id="budgeted_cost" type="text" >
                <label for="budgeted_cost">Budgeted Cost</label>
              </div>

              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">view_module</i>
                  <input id="actual_cost" type="text">
                <label for="actual_cost">Actual Cost</label>
              </div>
            </div>

        </div>
            <input id="user_id"  value="<?php echo $_SESSION['id'] ?>" type="hidden">
              <div class="row">
                <div class="input-field col m s12">
                  <button class="btn cyan waves-effect waves-light right" id="add">Submit
                    <i class="material-icons right">send</i>
                  </button>
                </div>                
              </div>         
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    
          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    <!-- Theme Customizer -->    
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>
    <script src="app-assets/js/costController.js" type="text/javascript"></script>
    <!-- END: Footer-->