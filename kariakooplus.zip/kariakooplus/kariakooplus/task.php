<!-- BEGIN: Head-->
<?php require_once("includes/header.php");?>
<!-- END: Header-->
<!-- BEGIN: SideNav-->
<?php require_once("includes/sidebar.php"); ?>
<!-- END: SideNav-->
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
        <div class="row">
          <div class="col s10 m6 l6 breadcrumbs-left">
            <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">TASK
            </h5>
          </div>
        </div>
      </div>
    </div>
    <div class="content-wrapper-before blue-grey lighten-5">
    </div>
    <div class="col s12">
      <div class="container">
        <div class="row">
          <div class="col s12 m12 l12">
            <div class="card subscriber-list-card animate fadeRight">
              <div class="card-content pb-1">
                <h4 class="card-title mb-0">
                  <a href="registerTask.php" class="waves-effect waves-light btn gradient-45deg-red-pink z-depth-4 mr-1 mb-2">New
                  </a>
                </h4>
              </div>
              <table class="subscription-table responsive-table highlight">
                <thead>
                  <tr>
                    <th>S/No
                    </th>
                    <th>Task name
                    </th>
                    <th>Start Date
                    </th>
                    <th>Dedline
                    </th>
                    <th>Status
                    </th>
                    <th>Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    $data = file_get_contents(BACKEND."task/getTasks");
                    $results = json_decode($data,true);
                    $index = 1;
                    foreach ($results as  $kw) {
                  ?>
                  <tr id="<?php echo $kw['task_id']; ?>">
                    <td>
                      <?php echo  $index; ?>
                    </td>
                    <td>
                      <?php echo (isset($kw["task_name"]))? $kw["task_name"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["start_date"]))? $kw["start_date"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["end_date"]))? $kw["end_date"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["status"]))? $kw["status"] : ""?>
                    </td>
                    <td>
                       <a class='dropdown-trigger'
                        href='#' data-target='<?php echo  $kw['task_id'].$kw["task_name"]; ?>'>
                        <i class="material-icons pink-text">more_vert
                        </i>
                       </a>
                       <!-- Dropdown Structure -->
                       <ul id='<?php echo  $kw['task_id'].$kw["task_name"]; ?>' class='dropdown-content'>
                       <li><a href="viewTask.php?id=<?php echo  $kw['task_id'];?>">View</a></li>
                       <li><a href="updateTask.php?id=<?php echo  $kw['task_id'];?>">Update</a></li>
                       <li class="divider"></li>
                       <li><a href="Javascript:deleteTask(<?php echo $kw['task_id'] ; ?>)">Delete</a></li>
                       </ul>
                    </td>
                  </tr>
                  <?php
                      $index++;
                      }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<!-- Theme Customizer -->
<!--/ Theme Customizer -->
<!-- BEGIN: Footer-->
<?php require_once("includes/footer.php"); ?>
<script  type="text/javascript">
function deleteTask(id){
Swal.fire({
  title: 'Are you sure ?',
  text: "You won't be able to recover this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {

    var settings = {
      "async": true,
      "crossDomain": true,
      "url":"http://localhost/magilatech-ms/user/"+id,
      "method": "POST",
      "headers": {
        "cache-control": "no-cache",
        "postman-token": "0820f20e-9bff-64c3-1b5b-9f115fc353cd"
      }
    }

    $.ajax(settings).done(function (response) {

      Swal.fire(
      'Deleted!',
       response.msg,
      'success'
      )
       $("tr#"+id+'').css("background-color",'#ccc');
       $("tr#"+id+'').fadeOut('slow');
      console.log(response);
    });

   
  }
})
};  

</script>

<!-- END: Footer-->
