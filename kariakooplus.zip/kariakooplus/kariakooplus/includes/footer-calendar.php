<!-- BEGIN: Footer-->

    <footer class="page-footer footer footer-static footer-dark gradient-45deg-purple-deep-orange gradient-shadow navbar-border navbar-shadow">
      <div class="footer-copyright">
        <div class="container"><span>&copy; 2019 Magilatech<a href="https://1.envato.market/pixinvent_portfolio" target="_blank"></a></span><span class="right hide-on-small-only"></a> All rights reserved.</a></span></div>
      </div>
    </footer>


    <!-- END: Footer-->
    <!-- BEGIN VENDOR JS-->
    <script src="app-assets/js/vendors.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="app-assets/vendors/fullcalendar/lib/jquery-ui.min.js"></script>
    <script src="app-assets/vendors/fullcalendar/lib/moment.min.js"></script>
    <script src="app-assets/vendors/fullcalendar/js/fullcalendar.min.js"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN THEME  JS-->
    <script src="app-assets/js/plugins.js" type="text/javascript"></script>
    <script src="app-assets/js/custom/custom-script.js" type="text/javascript"></script>
    <script src="app-assets/js/scripts/customizer.js" type="text/javascript"></script>
    <!-- END THEME  JS-->
    <!-- BEGIN PAGE LEVEL JS-->


    <script src="app-assets/vendors/sweetalert2/dist/sweetalert2.min.js"></script>
    <script src="app-assets/js/scripts/card-advanced.js" type="text/javascript"></script>
    <!-- END PAGE LEVEL JS-->
  </body>

<!-- Mirrored from pixinvent.com/materialize-material-design-admin-template/html/ltr/vertical-menu-nav-dark-template/app-calendar.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Oct 2019 07:31:30 GMT -->
</html>