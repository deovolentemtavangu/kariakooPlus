    <footer class="page-footer footer footer-static footer-dark gradient-45deg-purple-deep-orange gradient-shadow navbar-border navbar-shadow">
      <div class="footer-copyright">
        <div class="container"><span>&copy; 2019 Magilatech<a href="https://1.envato.market/pixinvent_portfolio" target="_blank"></a></span><span class="right hide-on-small-only"></a> All rights reserved.</a></span></div>
      </div>
    </footer>

    
    <!-- BEGIN VENDOR JS-->
    <script src="app-assets/js/vendors.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="app-assets/vendors/chartjs/chart.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/chartist-js/chartist.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/chartist-js/chartist-plugin-tooltip.js" type="text/javascript"></script>
    <script src="app-assets/vendors/chartist-js/chartist-plugin-fill-donut.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN THEME  JS-->
    <script src="app-assets/js/plugins.js" type="text/javascript"></script>
    <script src="app-assets/js/custom/custom-script.js" type="text/javascript"></script>
    <script src="app-assets/js/scripts/customizer.js" type="text/javascript"></script>
    <!-- END THEME  JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="app-assets/js/scripts/dashboard-modern.js" type="text/javascript"></script>
    <script src="app-assets/js/scripts/intro.js" type="text/javascript"></script>
    <script src="app-assets/js/scripts/vectormap-script.js" type="text/javascript"></script>
    <script type="text/javascript">
       
      $("#pie-chart-sample").sparkline([50, 60, 80, 110], {
        type: 'pie',
        width: '400',
        height: '500',
        //tooltipFormat: $.spformat('{{value}}', 'tooltip-class'),
        labels: ["B1", "B2", "B3", "B4", "B5"],
        sliceColors: ['#ab47bc', '#03a9f4', '#cddc39', '#ff7043',]
      });
       
    </script>
    <!--<script src="app-assets/js/scripts/dashboard-ecommerce.js" type="text/javascript"></script>-->    
    <!-- END PAGE LEVEL JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="app-assets/vendors/chartjs/chart.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->

    <script src="app-assets/vendors/sweetalert2/dist/sweetalert2.min.js"></script>
    <!-- BEGIN THEME  JS-->

    <script src="app-assets/js/custom/custom-script.js" type="text/javascript"></script>
    <!-- END THEME  JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <!-- END PAGE LEVEL JS-->

  </body>

<!-- Mirrored from pixinvent.com/materialize-material-design-admin-template/html/ltr/vertical-menu-nav-dark-template/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Oct 2019 07:25:46 GMT -->
</html>