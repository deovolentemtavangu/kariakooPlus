    <!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="content-wrapper-before blue-grey lighten-5"></div>
        <div class="col s12">
          <div class="container">
                 <!--card stats start-->
<div id="card-stats">
   <div class="row">
      <div class="col s12 m6 l6 xl3">
         <div class="card gradient-45deg-light-blue-cyan gradient-shadow min-height-100 white-text animate fadeLeft">
            <div class="padding-4">
               <div class="col s7 m7">
                  <i class="material-icons background-round mt-5">add_shopping_cart</i>
                  <p>Total Staff</p>
               </div>
               <div class="col s5 m5 right-align">
                  <h5 class="mb-0 white-text">69</h5>
                  <p class="no-margin">Developer</p>
                  <p>500</p>
               </div>
            </div>
         </div>
      </div>
      <div class="col s12 m6 l6 xl3">
         <div class="card gradient-45deg-amber-amber gradient-shadow min-height-100 white-text animate fadeRight">
            <div class="padding-4">
               <div class="col s7 m7">
                  <i class="material-icons background-round mt-5">timeline</i>
                  <p>New Staff</p>
               </div>
               <div class="col s5 m5 right-align">
                  <h5 class="mb-0 white-text">80%</h5>
                  <p class="no-margin">Operational</p>
                  <p>3</p>
               </div>
            </div>
         </div>
      </div>
      <div class="col s12 m6 l6 xl3">
         <div class="card gradient-45deg-red-pink gradient-shadow min-height-100 white-text animate fadeLeft">
            <div class="padding-4">
               <div class="col s7 m7">
                  <i class="material-icons background-round mt-5">perm_identity</i>
                  <p>Female Staff</p>
               </div>
               <div class="col s5 m5 right-align">
                  <h5 class="mb-0 white-text">20</h5>
                  <p class="no-margin">Opeational</p>
                  <p>5</p>
               </div>
            </div>
         </div>
      </div>
      
      <div class="col s12 m6 l6 xl3">
         <div class="card gradient-45deg-green-teal gradient-shadow min-height-100 white-text animate fadeRight">
            <div class="padding-4">
               <div class="col s7 m7">
                  <i class="material-icons background-round mt-5">attach_money</i>
                  <p>Male Staff</p>
               </div>
               <div class="col s5 m5 right-align">
                  <h5 class="mb-0 white-text">40</h5>
                  <p class="no-margin">Developers</p>
                  <p>600</p>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!--card stats end-->


<div class="row">
   <div class="col s12 m12 l12">
      <div class="card subscriber-list-card animate fadeRight">
         <div class="card-content pb-1">
            <h4 class="card-title mb-0">STAFF<a href="registerStaff.php" class="waves-effect waves-light btn gradient-45deg-red-pink z-depth-4 mr-1 mb-2 float-right">New</a></h4>
         </div>
         <table class="subscription-table responsive-table highlight">
            <thead>
               <tr>
                  <th>S/No</th>
                  <th>First name</th>
                  <th>Last name</th>
                  <th>Position</th>
                  <th>Gender</th>
                  <th>Action</th>
               </tr>
            </thead>
            <tbody>
               <?php
                     $data = file_get_contents(STAFF_BACKEND."getStaffs");
                     $results = json_decode($data,true);
                     $index = 1;
                     foreach ($results as  $kw) {
               ?>
               <tr id="<?php echo $kw['staff_id']; ?>">
                  <td><?php echo  $index; ?></td>
                  <td><?php echo (isset($kw["first_name"]))? $kw["first_name"] : ""?></td>
                  <td><?php echo (isset($kw["last_name"]))? $kw["last_name"] : ""?></td>
                  <td><?php echo (isset($kw["position"]))? $kw["position"] : ""?></td>
                  <td><?php echo (isset($kw["gender"]))? $kw["gender"] : ""?></td>
                  <td class="center-align"><a href="#"><i class="material-icons pink-text">more_vert</i></a></td>
               </tr>
                <?php
                    $index++;
                  }
                ?>
            </tbody>
         </table>
      </div>
   </div>
</div>

          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->

    <!-- Theme Customizer -->

    <!--/ Theme Customizer -->

 
    
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>
    <!-- END: Footer-->