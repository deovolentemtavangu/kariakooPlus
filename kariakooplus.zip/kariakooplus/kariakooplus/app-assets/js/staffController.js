    
$(document).ready(function(){

$("#add").click(function() {

var first_name =  $("#first_name").val();
var last_name = $("#last_name").val();
var phone_number = $("#phone_number").val();
var position = $("#position").val();
var gender = $("#gender").val();
var email = $("#email").val();
var password = $("#password").val();
var user_id = $("#user_id").val();

var settings = {
 "async": true,
 "crossDomain": true,
 "url": "http://localhost/magilatech-ms/user/registerStaff?first_name="+first_name+
 "&last_name="+last_name+"&phone_number="+phone_number+"&position="+position+
 "&gender="+gender+"&email="+email+"&created_by="+user_id+
 "&password="+password+"",
 "method": "POST",
 "headers": {
   "cache-control": "no-cache",
   "postman-token": "b3b239b4-08de-ecee-8e6b-6441ede4a23a"
 }
}

	$.ajax(settings).done(function (response) {
	 console.log(response);
	 if(response.error){
	  Swal.fire(
	      'Error Found ?',
	      response.error,
	      'error'
	    );}
	  
	else {

		if(response.status == "failed")
	{
	  Swal.fire(
	      'Error Found ?',
	      response.msg,
	      'error'
	    );}

	else if(response.status=="success"){
	    Swal.fire(
	         'Success!',
	          response.msg,
	         'success'
	     )}
	}
	    $(".card-content").html(response.msg);
	});
});
});


$("#update").click(function(){


   var first_name =  $("#first_name").val();
    var last_name = $("#last_name").val();
    var phone_number = $("#phone_number").val();
    var position = $("#position").val();
    var gender = $("#gender").val();
    var email = $("#email").val();
   
    var getId = $("#getId").val();


      var settings = {
      "async": true,
      "crossDomain": true,
      "url": "http://localhost/magilatech-ms/user/editStaff/"+getId+"?first_name="+first_name+"&email="+ email +"&last_name="+last_name+"&position="+ position +"&gender="+gender+"&phone_number="+phone_number+"",
      "method": "POST",
      "dataType":"json",
      "headers": {
        "authorization":  "",
        "cache-control": "no-cache",
        "postman-token": "88e60281-ced0-f9ce-8167-2baa6147c0cb"
      }
    }

    $.ajax(settings).done(function (data) {
        if(data.error){
           
             Swal.fire({
              type: 'error',
              title: 'Error Found !',
              text: data.error,
               
            });
           }else{
             
            if(data.status=="success"){
                 Swal.fire({
                  type: 'success',
                  title: 'Success',
                  text: data.msg,
                });
                $(".card-content").html(data.msg);
              }else if(data.status=="exist"){
                Swal.fire({
                type: 'error',
                title: 'Error Found !',
                text: data.msg,
                 
              });
            }else{
              Swal.fire({
                type: 'error',
                title: 'Error Found !',
                text: data.msg,
                 
              });
            }
           }
    });
     
}); 


function deleteStaff(id){

   
Swal.fire({
  title: 'Are you sure ?',
  text: "You won't be able to recover this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {

    var settings = {
      "async": true,
      "crossDomain": true,
      "url":"http://localhost/magilatech-ms/user/deleteStaff/"+id,
      "method": "POST",
      "headers": {
        "cache-control": "no-cache",
        "postman-token": "0820f20e-9bff-64c3-1b5b-9f115fc353cd"
      }
    }

    $.ajax(settings).done(function (response) {

      Swal.fire(
      'Deleted!',
       response.msg,
      'success'
      )
       $("tr#"+id+'').css("background-color",'#ccc');
       $("tr#"+id+'').fadeOut('slow');
      console.log(response);
    });

   
  }
})
};
