$("#login").click(function(){

  var email = $("#email").val();

  var  password = $("#password").val();

   var settings = {
    "async": true,
    "crossDomain": true,
    "url": "http://localhost/kariakooplus/kariakooplus-ms/user/authenticate1?email="+email+"&password="+password+"",
    "method": "POST",
    "headers": {
      "cache-control": "no-cache",
      "Postman-Token": "7aa21be5-b098-4047-ba00-ee00d28278bd"
    }
  }

  $.ajax(settings).done(function (data) {
     
     if(data.error){
            
             Swal.fire(
                'Error Found ?',
                data.error,
                'error'
              );
           }else{
             
            if(data.status=="success"){
                Swal.fire(
                'Login Success ?',
                 data.msg,
                'success'
                );
              
 
               $.ajax({  
                  type: 'POST',  
                  url: 'tokenizer.php', 
                  data: { token: data.token },
                  success: function(response) {
                     if(response == "success"){
                         window.location.href = "dashboard.php";
                        
                     }
                     
                  }
              });
                
              }else if(data.status=="exist"){
               Swal.fire(
                'Error Found ?',
                data.msg,
                'error'
              );
            }else{
              Swal.fire(
                'Error Found ?',
                data.msg,
                'error'
              );
            }
           }
  });

});

