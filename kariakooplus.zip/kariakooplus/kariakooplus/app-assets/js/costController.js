
$(document).ready(function(){
$("#add").click(function() {

    var project =  $("#project").val();
    var pharse =  $("#pharse").val();
	var budgeted_cost = $("#budgeted_cost").val();
	var actual_cost = $("#actual_cost").val();
	var description = $("#description").val();
	var user_id = $("#user_id").val();

	 var settings = {
	  "async": true,
	  "crossDomain": true,
	  "url": "http://localhost/magilatech-ms/cost/registerCost?pharse="+pharse+"&project="+project+"&created_by="+user_id+
	  "&budgeted_cost="+budgeted_cost+"&actual_cost="+actual_cost+"&description="+description+"",
	  "method": "POST",
	  "headers": {
	    "cache-control": "no-cache",
	    "postman-token": "b3b239b4-08de-ecee-8e6b-6441ede4a23a"
	  }
	}

	$.ajax(settings).done(function (response) {
	 console.log(response);
	 if(response.error){
	  Swal.fire(
	      'Error Found ?',
	      response.error,
	      'error'
	    );}
	  
	else {

		if(response.status == "failed")
	{
	  Swal.fire(
	      'Error Found ?',
	      response.msg,
	      'error'
	    );}

	else if(response.status=="success"){
	    Swal.fire(
	         'Success!',
	          response.msg,
	         'success'
	     )}
	}
	    $(".card-content").html(response.msg);
	});});
});