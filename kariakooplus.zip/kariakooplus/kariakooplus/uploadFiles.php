    <!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->
    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">UPLOAD FILES</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">

  <div class="row">
    <!-- Form -->
    <div class="col s12 m12 l12">
      <div id="Form-advance" class="card card card-default scrollspy">
        <div class="card-content">
          <h4 class="card-title"></h4>
          <div class="col s12"> 

            <div class="row">
              <div class="input-field col m12 s12">
                  <i class="material-icons prefix">business</i>
                  <?php
                      if(isset($_GET['id'])){

                      $id=$_GET['id'];   
                      $data = file_get_contents("student_ms/user/getProjectById/.$id");
                      $results = json_decode($data,true);

                      if(sizeof($results)>0){                  
                       $project_name = $results[0]['project_name'];
                       $project_id = $results[0]['project_id'];
                      }
                      else {
                       $project_name = '';
                       $project_id = '';
                      }
                      
                  ?>
                          <input type="text" value='<?php echo $project_name ?>' disabled='true'>
                          <input type="hidden" id='project' value='<?php echo $project_id ?>'>
                  <?php } ?>
                <label for="project_id">Project</label>
              </div>
            </div>

            <div id="container" class="col s12">
              <ul>
                <li id="filelist"></li>
              </ul>
               <a id="pickfiles" class="waves-effect waves-light btn gradient-45deg-red-pink z-depth-4 mr-1 mb-2">Browse files</a>
              <a id="uploadfiles" class="waves-effect waves-light btn gradient-45deg-amber-amber z-depth-4 mr-1 mb-2">Start upload</a>
            </div>

              </div>


<ul>
  <li id="filelist"></li>
</ul>
<pre id="console"></pre>
       
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    
          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    <!-- Theme Customizer -->    
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>
    <script src="app-assets/js/taskController.js" type="text/javascript"></script>

    <script type="text/javascript" src="app-assets/vendors/plupload-2.3.6/js/plupload.full.min.js"></script>
    <script type="text/javascript">
    // Custom example logic
    var file_name = '';

    var uploader = new plupload.Uploader({
      runtimes : 'html5,flash,silverlight,html4',
      browse_button : 'pickfiles', // you can pass an id...
      container: document.getElementById('container'), // ... or DOM Element itself
      url : 'upload.php',
      flash_swf_url : '../js/Moxie.swf',
      silverlight_xap_url : '../js/Moxie.xap',
      
      filters : {
        max_file_size : '10mb',
        mime_types: [
          {title : "Image files", extensions : "jpg,gif,png"},
          {title : "Zip files", extensions : "zip"}
        ]
      },

      init: {
        PostInit: function() {
          document.getElementById('filelist').innerHTML = '';

          document.getElementById('uploadfiles').onclick = function() {
            uploader.start();
            return false;
          };
        },

        FilesAdded: function(up, files) {
          plupload.each(files, function(file) {
            document.getElementById('filelist').innerHTML += '<div id="' + file.id + '">' + file.name + ' (' + plupload.formatSize(file.size) + ') <b></b></div>';
            

          });
        },

        UploadProgress: function(up, file) {
          document.getElementById(file.id).getElementsByTagName('b')[0].innerHTML = '<span>' + file.percent + "%</span>";
          
          // Post
          //alert(file.name + file.size + file.id);


        },



        Error: function(up, err) {
          document.getElementById('console').appendChild(document.createTextNode("\nError #" + err.code + ": " + err.message));
        }
      }


    });

    uploader.init();
    </script>            

    <!-- END: Footer-->