<!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">VIEW STAFF</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">

              <div class="row">
                <!-- Form -->
                <div class="col s12 m12 l12">
                  <div id="Form-advance" class="card card card-default scrollspy">
                    <div class="card-content">
                      <h4 class="card-title"></h4>
                      <div class="col s12">

                         
                         <?php
                         if(isset($_GET['id'])){

                            $id=$_GET['id'];
                            $user = file_get_contents(BACKEND ."user/getStaffById/$id");
                            $kw=json_decode($user,true);
                             
                                                           
                          ?>

                          <table class="table">
                           <tbody>
                              <tr style="">
                              <td style="border: none; font-weight: bold;">Created Date :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['created_at']))?$kw[0]['created_at']:"";?></td>
                              </tr>
                              <tr style="">
                              <td style="border: none; font-weight: bold;">First Name :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['first_name']))?$kw[0]['first_name']:"";?></td>
                              </tr>

                              <tr style="">
                              <td style="border: none; font-weight: bold;">Last Name :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['last_name']))?$kw[0]['last_name']:"";?></td>
                              </tr>

                              <tr style="">
                              <td style="border: none; font-weight: bold;">Phone Number :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['phone_number']))?$kw[0]['phone_number']:"";?></td>
                              </tr>

                              <tr style="">
                              <td style="border: none; font-weight: bold;">Gender :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['gender']))?$kw[0]['gender']:"";?></td>
                              </tr>

                              <tr style="">
                              <td style="border: none; font-weight: bold;">Position :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['position']))?$kw[0]['position']:"";?></td>
                              </tr>
                              <tr style="">

                              <td style="border: none; font-weight: bold;">Email :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['email']))?$kw[0]['email']:"";?></td>
                              </tr>

                               
                            </tbody>
                            </table>

                            <?php
                               }
                              ?>
                           
                           
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
   
          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    <!-- Theme Customizer -->

    <!--/ Theme Customizer -->

 
   
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>

     
    <script src="app-assets/js/staffController.js" type="text/javascript"></script>
    <!-- END: Footer-->