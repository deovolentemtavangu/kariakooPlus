    <!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">ADD PROJECT</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">

  <div class="row">
    <!-- Form -->
    <div class="col s12 m12 l12">
      <div id="Form-advance" class="card card card-default scrollspy">
        <div class="card-content">
          <h4 class="card-title"></h4>
          <div class="col s12">

            <div class="row">
              <div class="input-field col m s12">
                <i class="material-icons prefix">business</i>
                <input id="project_name" type="text">
                <label for="project_name">Project Name</label>
              </div>
            </div>

            <div class="row">
                <div class="input-field col s12">
                  <i class="material-icons prefix">message</i>
                  <textarea id="description" class="materialize-textarea"></textarea>
                  <label for="description">Description</label>
                </div>
            </div>
            
            <div class="row">
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">event</i>
                <input id="start_date" type="date">
                <label for="start_date">Start Date</label>
              </div>   
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">event</i>
                <input id="end_date" type="date">
                <label for="end_date">End Date</label>
              </div>       
              </div>

              <input id="user_id"  value="<?php echo $_SESSION['id'] ?>" type="hidden">

              <div class="row">
                <div class="input-field col m s12">
                  <button class="btn cyan waves-effect waves-light right" id="add" type="submit">Submit
                    <i class="material-icons right">send</i>
                  </button>
                </div>                
              </div>         
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    
          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    <!-- Theme Customizer -->    
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>

    <script src="app-assets/js/projectController" type="text/javascript"></script>

    <!-- END: Footer-->