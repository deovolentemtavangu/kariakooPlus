<!-- BEGIN: Head-->
<?php require_once("includes/header.php");?>
<!-- END: Header-->
<!-- BEGIN: SideNav-->
<?php require_once("includes/sidebar.php"); ?>
<!-- END: SideNav-->
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">

<div id="card-stats">

   <div class="row">

      <div class="col s12 m12 l12">
        <div class="card subscriber-list-card animate fadeRight">
            <div class="padding-4">

               <div class="col s3 m3">
            <p>Requirement</p>                   
              <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">
                <i class="material-icons gradient-45deg-green-teal white-text  background-round mt-5">check</i>
            </h5>
            <p>Complete</p>                
               </div>

               <div class="col s3 m3">
            <p>Designing</p>                   
              <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">
                <i class="material-icons gradient-45deg-green-teal white-text background-round mt-5">check</i>
            </h5>
            <p>Complete</p>                
               </div>

               <div class="col s3 m3">
            <p>Development</p>                
                  <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">
                    <a style="text-align: center; padding-top: 5px;" class= "btn-floating waves-effect btn-large  light-blue-cyan darken-4">60%
                    </a>
                  </h5>
                  <p>On Progress</p>                
               </div>

              <div class="col s3 m3">
            <p>Testing</p>                   
              <h5 class="">
                <i class="material-icons gradient-45deg-purple-deep-orange white-text background-round mt-5">alarm</i>
            </h5>
            <p>Waiting</p>                
               </div>


            </div>
        </div>
      </div>

   </div>



</div>
<!--card stats end-->


      </div>
    </div>
    <div class="content-wrapper-before blue-grey lighten-5">
    </div>
    <div class="col s12">
      <div class="container">
        <div class="row">

          <div class="col s12 m12 l12">
            <div class="card subscriber-list-card animate fadeRight">
              <div class="card-content pb-1">
                <h4 class="card-title mb-0">
                  Pharses List
                </h4>
              </div>
              <table class="subscription-table responsive-table highlight">
                <thead>
                  <tr>
                    <th>Pharses
                    </th>
                    <th>Health Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php
$data = file_get_contents(BACKEND."pharse/openProject");
$results = json_decode($data,true);
$index = 1;
foreach ($results as  $kw) {
?>
                  <tr id="<?php echo $kw['project_id']; ?>">
                    <td>
                      <?php echo (isset($kw["pharse_name"]))? $kw["pharse_name"] : ""?>
                    </td>
                    <td>
                          <div style="
                          width:100px; 
                          text-align: center; 
                          color: white;
                          -moz-border-radius: 25px;
                          -webkit-border-radius: 25px;
                          border-radius: 25px;
                          padding :200;
                          height:20px;
                          background: linear-gradient(to right, #03a9f4 70%, #81d4fa  30%);">70%
                        </div>
                    </td>
                  </tr>
                  <?php
$index++;
}
?>
                </tbody>
              </table>
            </div>
          </div>




        </div>
      </div>
    </div>

  </div>
</div>
<!-- END: Page Main-->
<!-- Theme Customizer -->
<!--/ Theme Customizer -->
<!-- BEGIN: Footer-->
<?php require_once("includes/footer.php"); ?>
<!-- END: Footer-->
