    <!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">EDIT STAFF</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">

  <div class="row">
    <!-- Form -->
    <div class="col s12 m12 l12">
      <div id="Form-advance" class="card card card-default scrollspy">
        <div class="card-content">
          <h4 class="card-title"></h4>
          <div class="col s12">

            <div class="row">
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">account_circle</i>
                <input id="first_name" type="text">
                <label for="first_name">First Name</label>
              </div>
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">account_circle</i>
                <input id="last_name" type="text">
                <label for="last_name">Last Name</label>
              </div>
            </div>

            <div class="row">
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">call</i>
                <input id="phone_number" type="text">
                <label for="phone_number">Phone Number</label>
              </div>
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">people</i>
                  <select id="position">
                  <option value="" disabled selected>Select Position</option>
                  <option value="Manager">Manager</option>
                  <option value="Developer">Developer</option>
                  <option value="Accountant">Accountant</option>
                </select>
                <label for="last_name">Position</label>
              </div>
            </div>

            <div class="row">
              <div class="input-field col m s12">
                  <i class="material-icons prefix">email</i>
                <input id="email" type="email">
                <label for="email">Email</label>
              </div>
            </div>

              <div class="row">
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">lock_outline</i>
                <input id="password" type="password">
                <label for="password">Password</label>
              </div>   
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">people</i>
                  <select id="gender">
                  <option value=""  selected>Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
                <label for="last_name">Gender</label>
              </div>                
              </div>

              <div class="row">
                <div class="input-field col m s12">
                  <button class="btn cyan waves-effect waves-light right" id="add" type="submit">Submit
                    <i class="material-icons right">send</i>
                  </button>
                </div>                
              </div>         
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    
          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    <!-- Theme Customizer -->

    <!--/ Theme Customizer -->

 
    
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>
    <script src="app-assets/js/staffController.js" type="text/javascript"></script>
    <!-- END: Footer-->