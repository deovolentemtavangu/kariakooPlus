<!-- BEGIN: Head-->
<?php require_once("includes/header.php");?>
<!-- END: Header-->
<!-- BEGIN: SideNav-->
<?php require_once("includes/sidebar.php"); ?>
<!-- END: SideNav-->
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">

<div id="card-stats">

   <div class="row">

      <div class="col s12 m6 l6 xl3">
         <div class="card gradient-45deg-green-teal gradient-shadow min-height-100 white-text animate fadeRight">
            <div class="padding-4">
               <div class="col s7 m7">
                  <i class="material-icons background-round mt-5">check</i>
                  <p>Requirement</p>
               </div>
               <div class="col s5 m5 right-align">
                  <p class="mb-0 white-text">100%</p>
                  <p class="no-margin">Done</p>
               </div>
            </div>
         </div>
      </div>

      <div class="col s12 m6 l6 xl3">
         <div class="card gradient-45deg-green-teal gradient-shadow min-height-100 white-text animate fadeRight">
            <div class="padding-4">
               <div class="col s7 m7">
                  <i class="material-icons background-round mt-5">check</i>
                  <p>Designing</p>
               </div>
               <div class="col s5 m5 right-align">
                  <p class="mb-0 white-text">100%</p>
                  <p class="no-margin">Done</p>
               </div>
            </div>
         </div>
      </div>

      <div class="col s12 m6 l6 xl3">
         <div class="card gradient-45deg-light-blue-cyan gradient-shadow min-height-100 white-text animate fadeRight">
            <div class="padding-4">
               <div class="col s7 m7">
                  <i class="material-icons background-round mt-5">timeline</i>
                  <p>Development</p>
               </div>
               <div class="col s5 m5 right-align">
                  <p class="mb-0 white-text">60%</p>
                  <p class="no-margin">On Progress</p>
               </div>
            </div>
         </div>
      </div>

      <div class="col s12 m6 l6 xl3">
         <div class="card gradient-45deg-purple-deep-orange gradient-shadow min-height-100 white-text animate fadeRight">
            <div class="padding-4">
               <div class="col s7 m7">
                  <i class="material-icons background-round mt-5">alarm</i>
                  <p>Testing</p>
               </div>
               <div class="col s5 m5 right-align">
                  <p class="mb-0 white-text">0%</p>
                  <p class="no-margin">Waiting</p>
               </div>
            </div>
         </div>
      </div>
   </div>



</div>
<!--card stats end-->


      </div>
    </div>
    <div class="content-wrapper-before blue-grey lighten-5">
    </div>
    <div class="col s12">
      <div class="container">

    <div class="row">
      <div class="col s12 m6 l6">
          <!-- Current Balance -->
      <div class="card animate fadeLeft" style="padding-bottom: 50px">
         <div class="card-content">
            <h4 class="card-title mb-0">Total Project Cost  <i class="material-icons float-right">more_vert</i></h4>
            <p class="medium-small">According to pharses</p>
                  <div id="doughnut-chart-wrapper">
                     <canvas  id="doughnut-chart" height="110"></canvas>
                  </div>
            <h5 class="center-align">$ 50,150.00</h5>
            <p class="medium-small center-align">Total Cost</p>
         </div>
      </div>
    </div>

      
      <div class="col s12 m6 l6">
          <!-- Current Balance -->
      <div class="card animate fadeLeft" style="padding-bottom: 50px">
         <div class="card-content">
            <h4 class="card-title mb-0">Overall Progress <i class="material-icons float-right">more_vert</i></h4>
            <p class="medium-small">According to pharses</p>
            <div class="current-balance-container">
               <div  id="current-balance-donut-chart" class="current-balance-shadow"></div>
            </div>
            <h5 class="center-align">80%</h5>
            <p class="medium-small center-align">Complete</p>
         </div>
      </div>
    </div>
  </div>

<div class="row">

<!--chart dashboard start-->
<div id="id="work-collections"">
      <div class="col s12 m6 l6">
         <ul id="projects-collection" class="collection z-depth-1 animate fadeLeft">
            <li class="collection-item avatar">
               <i class="material-icons cyan circle">card_travel</i>
               <h6 class="collection-header m-0">Overdue Task</h6>
            </li>
            <li class="collection-item">
               <div class="row">
                  <div class="col s6">
                     <p class="collections-title">Web App</p>
                     <p class="collections-content">AEC Company</p>
                  </div>
                  <div class="col s3"><span class="task-cat cyan">Development</span></div>
                  <div class="col s3">
                     <div id="project-line-1"></div>
                  </div>
               </div>
            </li>
            <li class="collection-item">
               <div class="row">
                  <div class="col s6">
                     <p class="collections-title">Mobile App for Social</p>
                     <p class="collections-content">iSocial App</p>
                  </div>
                  <div class="col s3"><span class="task-cat red accent-2">UI/UX</span></div>
                  <div class="col s3">
                     <div id="project-line-2"></div>
                  </div>
               </div>
            </li>
         </ul>
      </div>

      <div class="col s12 m6 l6">
          <!-- Current Balance -->
       <ul id="issues-collection" class="collection z-depth-1 animate fadeRight">
            <li class="collection-item avatar">
               <i class="material-icons red accent-2 circle">bug_report</i>
               <h6 class="collection-header m-0">Upcoming Dedline</h6>
            </li>
            <li class="collection-item">
               <div class="row">
                  <div class="col s7">
                     <p class="collections-title"><strong>#102</strong> Home Page</p>
                     <p class="collections-content">Web Project</p>
                  </div>
                  <div class="col s2"><span class="task-cat deep-orange accent-2">P1</span></div>
                  <div class="col s3">
                     <div class="progress">
                        <div class="determinate" style="width: 70%"></div>
                     </div>
                  </div>
               </div>
            </li>
            <li class="collection-item">
               <div class="row">
                  <div class="col s7">
                     <p class="collections-title"><strong>#108</strong> API Fix</p>
                     <p class="collections-content">API Project</p>
                  </div>
                  <div class="col s2"><span class="task-cat cyan">P2</span></div>
                  <div class="col s3">
                     <div class="progress">
                        <div class="determinate" style="width: 40%"></div>
                     </div>
                  </div>
               </div>
            </li>
         </ul>
      </div>
</div>
<!--chart dashboard end-->  
</div>


      <div class="row">
          <div class="col s12 m12 l12">
            <div class="card subscriber-list-card animate fadeRight">
              <div class="card-content pb-1">
                <h4 class="card-title mb-0">
                  Pharses Progress
                </h4>
              </div>
              <table class="subscription-table responsive-table highlight">
                <thead>
                  <tr>
                    <th>Pharses
                    </th>
                    <th>Health Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php
$data = file_get_contents(BACKEND."pharse/openProject");
$results = json_decode($data,true);
$index = 1;
foreach ($results as  $kw) {
?>
                  <tr id="<?php echo $kw['project_id']; ?>">
                    <td>
                      <?php echo (isset($kw["pharse_name"]))? $kw["pharse_name"] : ""?>
                    </td>
                    <td>
                          <div style="
                          width:100px; 
                          text-align: center; 
                          color: white;
                          -moz-border-radius: 25px;
                          -webkit-border-radius: 25px;
                          border-radius: 25px;
                          padding :200;
                          height:20px;
                          background: linear-gradient(to right, #03a9f4 70%, #81d4fa  30%);">70%
                        </div>
                    </td>
                  </tr>
                  <?php
$index++;
}
?>
                </tbody>
              </table>
            </div>
          </div>


        
</div>       


      </div>
    </div>

  </div>
</div>
<!-- END: Page Main-->
<!-- Theme Customizer -->
<!--/ Theme Customizer -->
<!-- BEGIN: Footer-->
<?php require_once("includes/footer.php"); ?>
<!-- END: Footer-->
