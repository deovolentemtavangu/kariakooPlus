<!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">Update STAFF</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">
     <?php
      if($_GET['id']){

      $id=$_GET['id'];
      $staff = file_get_contents(BACKEND ."user/getStaffById/$id");
      $kw=json_decode($staff,true);

    }   
    ?>
  <div class="row">
    <!-- Form -->
    <div class="col s12 m12 l12">
      <div id="Form-advance" class="card card card-default scrollspy">
        <div class="card-content">
          <h4 class="card-title"></h4>
          <div class="col s12">

            <div class="row">
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">account_circle</i>
                <input id="first_name" type="text" value="<?php echo  (isset($kw[0]['first_name']))?$kw[0]['first_name']:"";?>">
                <label for="first_name">First Name</label>
              </div>
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">account_circle</i>
                <input id="last_name" type="text" value="<?php echo  (isset($kw[0]['last_name']))?$kw[0]['last_name']:"";?>">
                <label for="last_name">Last Name</label>
              </div>
            </div>

            <div class="row">
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">call</i>
                <input id="phone_number" type="text" value="<?php echo  (isset($kw[0]['phone_number']))?$kw[0]['phone_number']:"";?>">
                <label for="phone_number">Phone Number</label>
              </div>
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">people</i>
                  <select id="position">
                  <option selected value="<?php echo  (isset($kw[0]['position']))?$kw[0]['position']:"";?>"><?php echo  (isset($kw[0]['position']))?$kw[0]['position']:"";?></option>
                  <option value="Manager">Manager</option>
                  <option value="Developer">Developer</option>
                  <option value="Accountant">Accountant</option>
                </select>
                <label for="last_name">Position</label>
              </div>
            </div>

            <div class="row">
              <div class="input-field col m s12">
                  <i class="material-icons prefix">email</i>
                <input id="email" type="email" value="<?php echo  (isset($kw[0]['email']))?$kw[0]['email']:"";?>">
                <label for="email">Email</label>
              </div>
            </div>

              <div class="row">
              <div class="input-field col m s12">
                  <i class="material-icons prefix">people</i>
                  <select id="gender">
                  <option value="<?php echo  (isset($kw[0]['gender']))?$kw[0]['gender']:"";?>"><?php echo  (isset($kw[0]['gender']))?$kw[0]['gender']:"";?></option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
                <label for="last_name">Gender</label>
              </div>                
              </div>
               <input type="hidden" id="getId" value="<?php echo $_GET["id"];?>">

              <div class="row">
                <div class="input-field col m s12">
                  <button class="btn cyan waves-effect waves-light right" id="update"  type="submit">Update
                    <i class="material-icons right">send</i>
                  </button>
                </div>                
              </div>    
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
   
          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    <!-- Theme Customizer -->

    <!--/ Theme Customizer -->

 
   
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>
  <script  type="text/javascript">
$("#update").click(function(){


   var first_name =  $("#first_name").val();
    var last_name = $("#last_name").val();
    var phone_number = $("#phone_number").val();
    var position = $("#position").val();
    var gender = $("#gender").val();
    var email = $("#email").val();
   
    var getId = $("#getId").val();


      var settings = {
      "async": true,
      "crossDomain": true,
      "url": "http://50.116.46.162/magilatech-ms/user/editStaff/"+getId+"?first_name="+first_name+"&email="+ email +"&last_name="+last_name+"&position="+ position +"&gender="+gender+"&phone_number="+phone_number+"",
      "method": "POST",
      "dataType":"json",
      "headers": {
        "authorization":  "",
        "cache-control": "no-cache",
        "postman-token": "88e60281-ced0-f9ce-8167-2baa6147c0cb"
      }
    }

    $.ajax(settings).done(function (data) {
        if(data.error){
           
             Swal.fire({
              type: 'error',
              title: 'Error Found !',
              text: data.error,
               
            });
           }else{
             
            if(data.status=="success"){
                 Swal.fire({
                  type: 'success',
                  title: 'Success',
                  text: data.msg,
                });
                $(".card-content").html(data.msg);
              }else if(data.status=="exist"){
                Swal.fire({
                type: 'error',
                title: 'Error Found !',
                text: data.msg,
                 
              });
            }else{
              Swal.fire({
                type: 'error',
                title: 'Error Found !',
                text: data.msg,
                 
              });
            }
           }
    });
     
}); 


  </script>
    <!-- END: Footer-->