    <!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">UPDATE TASK</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">

           <?php
            if(isset($_GET['id'])){

            $id=$_GET['id'];
            $task = file_get_contents(BACKEND ."task/getTaskById/$id");
            $task_kw=json_decode($task,true);

            $pharse=$_GET['pharse'];
            $pharse = file_get_contents(BACKEND ."pharse/getPharseById/$pharse");
            $pharse_kw=json_decode($pharse,true);

            $project=$_GET['project'];
            $project = file_get_contents(BACKEND ."project/getProjectById/$project");
            $project_kw=json_decode($project,true);

            $staff=$_GET['staff'];
            $staff = file_get_contents(BACKEND ."user/getStaffById/$staff");
            $staff_kw=json_decode($staff,true);


            ?>

  <div class="row">
    <!-- Form -->
    <div class="col s12 m12 l12">
      <div id="Form-advance" class="card card card-default scrollspy">
        <div class="card-content">
          <h4 class="card-title"></h4>
          <div class="col s12">

            <div class="row">
              <div class="input-field col m s12">
                  <i class="material-icons prefix">message</i>
                  <input id="task_name" value="<?php echo  (isset($task_kw[0]['task_name']))?$task_kw[0]['task_name']:"";?>" type="text">
                <label for="task_name">Task Name</label>
              </div>
              </div> 

            <div class="row">
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">filter_list</i>
                  <select id="pharse">
                  <option  value="<?php echo $pharse_kw[0]['pharse_id'] ?>" selected><?php echo $pharse_kw[0]['pharse_name'] ?></option>
                  <?php
                  $data = file_get_contents(BACKEND."pharse/openProject/$id");
                  $results = json_decode($data,true);
                  foreach ($results as  $kw) {
                  ?>
                  <option value="<?php echo $kw["pharse_id"] ?>"><?php echo $kw["pharse_name"] ?></option>
                  <?php } ?>
                </select>
                <label for="pharse_name">Pharse</label>
              </div>

              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">business</i>
                  <select id="project">
                   <option value="<?php echo $pharse_kw[0]['project_id'] ?>"  selected><?php echo $pharse_kw[0]['project_name'] ?></option> 
                    <?php
                    $data = file_get_contents(BACKEND."project/getProjects");
                    $results = json_decode($data,true);
                    $index = 1;
                    foreach ($results as  $project) {
                    ?>
                  <option value='<?php echo $project['project_id'] ?>'><?php echo $project["project_name"] ?>
                  </option>
                    <?php } ?>
                </select>
                <label for="project_id">Project</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">account_circle</i>
                  <select id="accountable">
                  <option value="<?php echo $staff_kw[0]['staff_id'] ?>"  selected><?php echo $staff_kw[0]['first_name']. " ".$staff_kw[0]['first_name']?></option>
                    <?php
                    $data = file_get_contents(BACKEND."user/getStaffs");
                    $results = json_decode($data,true);
                    $index = 1;
                    foreach ($results as  $staff) {
                    ?>
                  <option value="<?php echo $staff["staff_id"] ?>"><?php echo $staff["first_name"]." ".$staff["first_name"] ?>
                  </option>
                   <?php } ?>                  
                </select>
                <label for="accountable">Accountable</label>
              </div>

              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">trending_up</i>
                  <select id="status">
                  <option value="<?php echo $task_kw[0]["status"] ?>" selected><?php echo $task_kw[0]["status"] ?></option>
                  <option value="Waiting">Waiting</option>
                  <option value="On progress">On progress</option>
                  <option value="Completed">Completed</option>
                </select>
                <label for="status">Status</label>
              </div>
            </div>           
            
            <div class="row">
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">event</i>
                <input id="start_date" type="date" value="<?php echo  (isset($task_kw[0]['start_date']))?$task_kw[0]['start_date']:"";?>">
                <label for="start_date">Start Date</label>
              </div>   
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">event</i>
                <input id="end_date" type="date" value="<?php echo  (isset($task_kw[0]['end_date']))?$task_kw[0]['end_date']:"";?>">
                <label for="end_date">End Date</label>

              </div>       
              </div>
              <input type="hidden" id="getId" value="<?php echo $_GET["id"];?>">
              <div class="row">
                <div class="input-field col m s12">
                  <button class="btn cyan waves-effect waves-light right" id="update">Update
                    <i class="material-icons right">send</i>
                  </button>
                </div>                
              </div>         
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    
    <?php } ?>

          </div>
        </div>
      </div>
    </div>
<!-- END: Page Main-->
<!-- Theme Customizer -->    
<!-- BEGIN: Footer-->
<?php require_once("includes/footer.php"); ?>
  <script  type="text/javascript">
  $("#update").click(function(){


    var project =  $("#project").val();
    var pharse =  $("#pharse").val();
    var task_name = $("#task_name").val();
    var status = $("#status").val();
    var accountable = $("#accountable").val();
    var start_date = $("#start_date").val();
    var end_date = $("#end_date").val();
     
    var getId = $("#getId").val();


    var settings = {
    "async": true,
    "crossDomain": true,
    "url": "http://localhost/magilatech-ms/task/editTask/"+getId+"?task_name="+task_name+"&status="+status+"&start_date="+start_date+"&end_date="+end_date+"",
    "method": "POST",
    "dataType":"json",
    "headers": {
      "authorization":  "",
      "cache-control": "no-cache",
      "postman-token": "88e60281-ced0-f9ce-8167-2baa6147c0cb"
    }
  }

      $.ajax(settings).done(function (data) {
          if(data.error){
             
               Swal.fire({
                type: 'error',
                title: 'Error Found !',
                text: data.error,
                 
              });
             }else{
               
              if(data.status=="success"){
                   Swal.fire({
                    type: 'success',
                    title: 'Success',
                    text: data.msg,
                  });
                  $(".card-content").html(data.msg);
                }else if(data.status=="exist"){
                  Swal.fire({
                  type: 'error',
                  title: 'Error Found !',
                  text: data.msg,
                   
                });
              }else{
                Swal.fire({
                  type: 'error',
                  title: 'Error Found !',
                  text: data.msg,
                   
                });
              }
             }
      });
       
  }); 
  </script>
<!-- END: Footer-->