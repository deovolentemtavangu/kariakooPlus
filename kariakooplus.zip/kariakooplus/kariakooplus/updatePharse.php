    <!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">UPDATE PHARSE</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">


     <?php
      if($_GET['id']){

      $id=$_GET['id'];
      $pharse = file_get_contents(BACKEND ."pharse/getPharseById/$id");
      $pharse_kw=json_decode($pharse,true);
      
      $staff=$_GET['staff'];
      $staff = file_get_contents(BACKEND ."user/getStaffById/$staff");
      $staff_kw=json_decode($staff,true);
    }   
    ?>

  <div class="row">
    <!-- Form -->
    <div class="col s12 m12 l12">
      <div id="Form-advance" class="card card card-default scrollspy">
        <div class="card-content">
          <h4 class="card-title"></h4>
          <div class="col s12">

            <div class="row">
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">filter_list</i>
                  <input type="text" value="<?php echo  (isset($pharse_kw[0]['pharse_name']))?$pharse_kw[0]['pharse_name']:"";?>" disabled = "true">
                <label for="pharse_name">Pharse</label>
              </div>

              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">business</i>
                  <input type="text" value="<?php echo  (isset($pharse_kw[0]['project_name']))?$pharse_kw[0]['project_name']:"";?>" disabled = "true">

                  <input type="hidden" value="<?php echo  (isset($pharse_kw[0]['project_id']))?$pharse_kw[0]['project_id']:"";?>" id="project_id">

                <label for="project_id">Project</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">view_module</i>
                  <select id="department">
                  <option  value="<?php echo $pharse_kw[0]["department"] ?>" selected>Operational</option>
                  <option value="1">Operational</option>
                  <option value="2">Development</option>
                  <option value="3">Finace</option>
                </select>
                <label for="department">Department</label>
              </div>

              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">trending_up</i>
                  <select id="status">
                  <option value="<?php echo $pharse_kw[0]["status"] ?>"  selected><?php echo $pharse_kw[0]["status"] ?></option>
                  <option value="Waiting">Waiting</option>
                  <option value="On progress">On progress</option>
                  <option value="Completed">Completed</option>
                </select>
                <label for="status">Status</label>
              </div>
            </div>

            <div class="row">
              <div class="input-field col m s12">
                  <i class="material-icons prefix">account_circle</i>
                  <select id="accountable">
                  <option value="<?php echo $staff_kw[0]['staff_id'] ?>"  selected><?php echo $staff_kw[0]['first_name']. " ".$staff_kw[0]['first_name']?></option>
                    <?php
                    $data = file_get_contents(BACKEND."user/getStaffs");
                    $results = json_decode($data,true);
                    $index = 1;
                    foreach ($results as  $kw) {
                    ?>
                  <option value="<?php echo $kw["staff_id"] ?>"><?php echo $kw["first_name"]." ".$kw["first_name"] ?>
                  </option>
                    <?php } ?>                  
                </select>
                <label for="accountable">Accountable</label>
              </div>
              </div>            
            
            <div class="row">
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">event</i>
                <input id="start_date" value="<?php echo  (isset($pharse_kw[0]['start_date']))?$pharse_kw[0]['start_date']:"";?>" type="date">
                <label for="start_date">Start Date</label>
              </div>   
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">event</i>
                <input id="end_date" value="<?php echo  (isset($pharse_kw[0]['end_date']))?$pharse_kw[0]['end_date']:"";?>" type="date">
                <label for="end_date">End Date</label>
              </div>       
              </div>

              <input type="hidden" id="getId" value="<?php echo $_GET["id"];?>">

              <div class="row">
                <div class="input-field col m s12">
                  <button class="btn cyan waves-effect waves-light right" id="update">Submit
                    <i class="material-icons right">send</i>
                  </button>
                </div>                
              </div>         
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    
          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    <!-- Theme Customizer -->    
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>
<script  type="text/javascript">

$("#update").click(function(){
  var project_id =   $("#project_id").val();
  var pharse_name =  $("#pharse_name").val();
  var department =   $("#department").val();
  var status = $("#status").val();
  var accountable = $("#accountable").val();
  var start_date = $("#start_date").val();
  var end_date = $("#end_date").val();

   
  var getId = $("#getId").val();


  var settings = {
  "async": true,
  "crossDomain": true,
  "url": "http://localhost/magilatech-ms/pharse/editPharse/"+getId+"?project_id="+project_id+"&status="+status+
  "&start_date="+start_date+"&end_date="+end_date+"",
  "method": "POST",
  "dataType":"json",
  "headers": {
    "authorization":  "",
    "cache-control": "no-cache",
    "postman-token": "88e60281-ced0-f9ce-8167-2baa6147c0cb"
  }
}

    $.ajax(settings).done(function (data) {
        if(data.error){
           
             Swal.fire({
              type: 'error',
              title: 'Error Found !',
              text: data.error,
               
            });
           }else{
             
            if(data.status=="success"){
                 Swal.fire({
                  type: 'success',
                  title: 'Success',
                  text: data.msg,
                });
                $(".card-content").html(data.msg);
              }else if(data.status=="exist"){
                Swal.fire({
                type: 'error',
                title: 'Error Found !',
                text: data.msg,
                 
              });
            }else{
              Swal.fire({
                type: 'error',
                title: 'Error Found !',
                text: data.msg,
                 
              });
            }
           }
    });
     
}); 
</script>
    <!-- END: Footer-->