    <!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">UPDATE PROJECT</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">

     <?php
      if($_GET['id']){

      $id=$_GET['id'];
      $staff = file_get_contents(BACKEND ."project/getProjectById/$id");
      $kw=json_decode($staff,true);

    }   
    ?>


  <div class="row">
    <!-- Form -->
    <div class="col s12 m12 l12">
      <div id="Form-advance" class="card card card-default scrollspy">
        <div class="card-content">
          <h4 class="card-title"></h4>
          <div class="col s12">

            <div class="row">
              <div class="input-field col m s12">
                <i class="material-icons prefix">business</i>
                <input id="project_name" value="<?php echo  (isset($kw[0]['project_name']))?$kw[0]['project_name']:"";?>" type="text">
                <label for="project_name">Project Name</label>
              </div>
            </div>

            <div class="row">
                <div class="input-field col s12">
                  <i class="material-icons prefix">message</i>
                  <textarea id="description" class="materialize-textarea"><?php echo  (isset($kw[0]['description']))?$kw[0]['description']:"";?></textarea>
                  <label for="description">Description</label>
                </div>
            </div>
            
            <div class="row">
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">event</i>
                <input id="start_date" value="<?php echo  (isset($kw[0]['start_date']))?$kw[0]['start_date']:"";?>" type="date">
                <label for="start_date">Start Date</label>
              </div>   
              <div class="input-field col m6 s12">
                <i class="material-icons prefix">event</i>
                <input id="end_date" value="<?php echo  (isset($kw[0]['end_date']))?$kw[0]['end_date']:"";?>" type="date">
                <label for="end_date">End Date</label>
              </div>       
              </div>
              <input type="hidden" id="getId" value="<?php echo $_GET["id"];?>">

              <div class="row">
                <div class="input-field col m s12">
                  <button class="btn cyan waves-effect waves-light right" id="update" type="submit">Update
                    <i class="material-icons right">send</i>
                  </button>
                </div>                
              </div>         
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    
          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    <!-- Theme Customizer -->    
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>
    <script  type="text/javascript">

$("#update").click(function(){
      var project_name =  $("#project_name").val();
      var description = $("#description").val();
      var start_date = $("#start_date").val();
      var end_date = $("#end_date").val();
       
        var getId = $("#getId").val();

          var settings = {
          "async": true,
          "crossDomain": true,
          "url": "http://localhost/magilatech-ms/project/editProject/"+getId+"?project_name="+project_name+
        "&description="+description+"&start_date="+start_date+"&end_date="+end_date+"",
          "method": "POST",
          "dataType":"json",
          "headers": {
            "authorization":  "",
            "cache-control": "no-cache",
            "postman-token": "88e60281-ced0-f9ce-8167-2baa6147c0cb"
          }
        }

        $.ajax(settings).done(function (data) {
            if(data.error){
               
                 Swal.fire({
                  type: 'error',
                  title: 'Error Found !',
                  text: data.error,
                   
                });
               }else{
                 
                if(data.status=="success"){
                     Swal.fire({
                      type: 'success',
                      title: 'Success',
                      text: data.msg,
                    });
                    $(".card-content").html(data.msg);
                  }else if(data.status=="exist"){
                    Swal.fire({
                    type: 'error',
                    title: 'Error Found !',
                    text: data.msg,
                     
                  });
                }else{
                  Swal.fire({
                    type: 'error',
                    title: 'Error Found !',
                    text: data.msg,
                     
                  });
                }
               }
        });
         
    });      

    </script>
    <!-- END: Footer-->