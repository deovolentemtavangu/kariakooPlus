    <!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">EDIT COST</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">

            <?php

            if(isset($_GET['id'])){

            $id=$_GET['id'];
            $cost = file_get_contents(BACKEND ."cost/getCostById/$id");
            $cost_kw=json_decode($cost,true);

            ?>


  <div class="row">
    <!-- Form -->
    <div class="col s12 m12 l12">
      <div id="Form-advance" class="card card card-default scrollspy">
        <div class="card-content">
          <h4 class="card-title"></h4>
          <div class="col s12">

            <div class="row">
              <div class="input-field col m s12">
                  <i class="material-icons prefix">message</i>
                <label for="description">Cost Description</label>
                <input type="text" value="<?php echo  (isset($cost_kw[0]['description']))?$cost_kw[0]['description']:"";?>" id="description">
              </div>
              </div>            

            <div class="row">
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">business</i>
                  <input type="text"  value="<?php echo  (isset($cost_kw[0]['project_name']))?$cost_kw[0]['project_name']:"";?>" disabled="true">
                  <input type="hidden"  value="<?php echo  (isset($cost_kw[0]['project_id']))?$cost_kw[0]['project_id']:"";?>" id="project">
                <label for="project">Project</label>
              </div>

              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">filter_list</i>
                  <select id="pharse">
                  <option  value="<?php echo  (isset($cost_kw[0]['pharse']))?$cost_kw[0]['pharse']:"";?>" selected><?php echo  (isset($cost_kw[0]['pharse']))?$cost_kw[0]['pharse']:"";?></option>
                  <option value="Requirement">Requirement and Analysis</option>
                  <option value="Designing">Designing</option>
                  <option value="Development">Development</option>
                  <option value="Testing">Testing</option>
                  <option value="Deployment">Deployment</option>
                  <option value="Documentation">Documentation</option>
                </select>
                <label for="pharse_name">Pharse</label>
              </div>

            </div>
            <div class="row">
              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">view_module</i>
                  <input id="budgeted_cost" value="<?php echo  (isset($cost_kw[0]['budgeted_cost']))?$cost_kw[0]['budgeted_cost']:"";?>" type="text" >
                <label for="budgeted_cost">Budgeted Cost</label>
              </div>

              <div class="input-field col m6 s12">
                  <i class="material-icons prefix">view_module</i>
                  <input id="actual_cost" value="<?php echo  (isset($cost_kw[0]['actual_cost']))?$cost_kw[0]['actual_cost']:"";?>" type="text">
                <label for="actual_cost">Actual Cost</label>
              </div>
            </div>
        </div>

         <input type="hidden" id="getId" value="<?php echo $_GET["id"];?>">

              <div class="row">
                <div class="input-field col m s12">
                  <button class="btn cyan waves-effect waves-light right" id="update">Submit
                    <i class="material-icons right">send</i>
                  </button>
                </div>                
              </div>         
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    
          <?php } ?>

          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    <!-- Theme Customizer -->    
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>
    <script  type="text/javascript">
      $("#update").click(function(){

      var project =  $("#project").val();
      var pharse =  $("#pharse").val();
      var budgeted_cost = $("#budgeted_cost").val();
      var actual_cost = $("#actual_cost").val();
      var description = $("#description").val();

      alert(project);

         
        var getId = $("#getId").val();


        var settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://50.116.46.162/magilatech-ms/cost/editCost/"+getId+"?pharse="+pharse+"&project="+project+
        "&budgeted_cost="+budgeted_cost+"&actual_cost="+actual_cost+"&description="+description+"",
        "method": "POST",
        "dataType":"json",
        "headers": {
          "authorization":  "",
          "cache-control": "no-cache",
          "postman-token": "88e60281-ced0-f9ce-8167-2baa6147c0cb"
        }
      }

          $.ajax(settings).done(function (data) {
              if(data.error){
                 
                   Swal.fire({
                    type: 'error',
                    title: 'Error Found !',
                    text: data.error,
                     
                  });
                 }else{
                   
                  if(data.status=="success"){
                       Swal.fire({
                        type: 'success',
                        title: 'Success',
                        text: data.msg,
                      });
                      $(".card-content").html(data.msg);
                    }else if(data.status=="exist"){
                      Swal.fire({
                      type: 'error',
                      title: 'Error Found !',
                      text: data.msg,
                       
                    });
                  }else{
                    Swal.fire({
                      type: 'error',
                      title: 'Error Found !',
                      text: data.msg,
                       
                    });
                  }
                 }
          });
           
      }); 
      </script>
    <!-- END: Footer-->