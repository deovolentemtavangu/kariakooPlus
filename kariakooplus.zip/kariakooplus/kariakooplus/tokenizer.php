<?php

session_start();

if(isset($_POST["token"])){

	$token =$_POST["token"];

	$_SESSION["token"] = $token;

   
    
	$curl = curl_init();

    curl_setopt_array($curl, array(
	  CURLOPT_URL => "http://localhost/kariakooplus-ms/user/getTokenData1?token=$token",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "GET",
	  CURLOPT_POSTFIELDS => "",
	  CURLOPT_HTTPHEADER => array(
	    "Postman-Token: 1e107994-8a0f-4d74-aa0a-f84496e18061",
	    "cache-control: no-cache"
	  ),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
	  echo "cURL Error #:" . $err;
	} else {
	  $response = json_decode($response,true);

      $_SESSION["id"] = $response["token_data"]["id"];
      $_SESSION["fname"] = $response["token_data"]["fname"];
      $_SESSION["lname"] = $response["token_data"]["lname"];
      $_SESSION["email"] = $response["token_data"]["email"];
     

	  echo $response["status"];
	}
	 
}
else{
	echo 'No token';
}
?>
