<!-- BEGIN: Head-->
<?php require_once("includes/header.php");?>
<!-- END: Header-->
<!-- BEGIN: SideNav-->
<?php require_once("includes/sidebar.php"); ?>
<!-- END: SideNav-->
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
        <div class="row">
          <div class="col s10 m6 l6 breadcrumbs-left">
            <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">PHARSES
            </h5>
          </div>
        </div>
      </div>
    </div>
    <div class="content-wrapper-before blue-grey lighten-5">
    </div>
    <div class="col s12">
      <div class="container">
        <div class="row">
          <div class="col s12 m12 l12">
            <div class="card subscriber-list-card animate fadeRight">
              <div class="card-content pb-1">
                <h4 class="card-title mb-0">
                  <a href="registerPharse.php" class="waves-effect waves-light btn gradient-45deg-red-pink z-depth-4 mr-1 mb-2">New
                  </a>
                </h4>
              </div>
              <table class="subscription-table responsive-table highlight">
                <thead>
                  <tr>
                    <th>S/No
                    </th>
                    <th>Project name
                    </th>
                    <th>Pharse name
                    </th>
                    <th>Started At
                    </th>
                    <th>Status
                    </th>                    
                    <th>Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $data = file_get_contents(BACKEND."pharse/getPharses");
                      $results = json_decode($data,true);

                      $index = 1;
                      foreach ($results as  $kw) {
                      ?>
                  <tr id="<?php echo $kw['pharse_id']; ?>">
                    <td>
                      <?php echo  $index; ?>
                    </td>
                    <td>
                      <?php echo (isset($kw["project_name"]))? $kw["project_name"] : ""?>
                    </td>                    
                    <td>
                      <?php echo (isset($kw["pharse_name"]))? $kw["pharse_name"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["enddate"]))? $kw["enddate"] : ""?>
                    </td>
                    <td>
                      <?php echo (isset($kw["pharseStatus"]))? $kw["pharseStatus"] : ""?>
                    </td>
                    <td>
                       <a class='dropdown-trigger'
                        href='#' data-target='<?php echo  $kw['pharse_id'].$kw["pharse_name"]; ?>'>
                        <i class="material-icons pink-text">more_vert
                        </i>
                       </a>
                       <!-- Dropdown Structure -->
                       <ul id='<?php echo  $kw['pharse_id'].$kw["pharse_name"]; ?>' class='dropdown-content'>
                       <li><a href="viewPharse.php?id=<?php echo  $kw['pharse_id'];?>">View</a></li>
                       <li><a href="updatePharse.php?id=<?php echo  $kw['pharse_id'];?>">Update</a></li>
                       <li class="divider"></li>
                       <li><a href="Javascript:deletePharse(<?php echo $kw['pharse_id'] ; ?>)">Delete</a></li>
                       </ul>
                    </td>
                  </tr>
                  <?php
                    $index++;
                    }
                    ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<!-- Theme Customizer -->
<!--/ Theme Customizer -->
<!-- BEGIN: Footer-->
<?php require_once("includes/footer.php"); ?>
<!-- END: Footer-->
