<!-- BEGIN: Head-->
    <?php require_once("includes/header.php");?>
    <!-- END: Header-->

    <!-- BEGIN: SideNav-->
    <?php require_once("includes/sidebar.php"); ?>
    <!-- END: SideNav-->

    <!-- BEGIN: Page Main-->
    <div id="main">
      <div class="row">
        <div class="breadcrumbs-inline pt-3 pb-1" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6 breadcrumbs-left">
                <h5 class="breadcrumbs-title mt-0 mb-0 display-inline hide-on-small">VIEW TASK</h5>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">

              <div class="row">
                <!-- Form -->
                <div class="col s12 m12 l12">
                  <div id="Form-advance" class="card card card-default scrollspy">
                    <div class="card-content">
                      <h4 class="card-title"></h4>
                      <div class="col s12">

                         
                         <?php
                         if(isset($_GET['id'])){

                            $id=$_GET['id'];
                            $user = file_get_contents(BACKEND ."task/getTaskById/$id");
                            $kw=json_decode($user,true);
                             
                                                           
                          ?>

                          <table class="table">
                           <tbody>

                              <tr style="">
                              <td style="border: none; font-weight: bold;">Task Name :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['task_name']))?$kw[0]['task_name']:"";?></td>
                              </tr>

                              <tr style="">
                              <td style="border: none; font-weight: bold;">Created Date :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['created_at']))?$kw[0]['created_at']:"";?></td>
                              </tr>

                              <tr style="">
                              <td style="border: none; font-weight: bold;">Start Date :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['start_date']))?$kw[0]['start_date']:"";?></td>
                              </tr>

                              <tr style="">
                              <td style="border: none; font-weight: bold;">End Date :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['end_date']))?$kw[0]['end_date']:"";?></td>
                              </tr>

                              <tr style="">
                              <td style="border: none; font-weight: bold;">Status :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['status']))?$kw[0]['status']:"";?></td>
                              </tr>

                              <tr style="">
                              <td style="border: none; font-weight: bold;">Category :</td>
                              <td style="border: none;"><?php echo  (isset($kw[0]['category']))?$kw[0]['category']:"";?></td>
                              </tr>

                              </tr>

                               
                            </tbody>
                            </table>

                            <?php
                               }
                              ?>
                           
                           
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
   
          </div>
        </div>
      </div>
    </div>
    <!-- END: Page Main-->
    <!-- Theme Customizer -->

    <!--/ Theme Customizer -->

 
   
    <!-- BEGIN: Footer-->
    <?php require_once("includes/footer.php"); ?>

     
    <script src="app-assets/js/staffController.js" type="text/javascript"></script>
    <!-- END: Footer-->