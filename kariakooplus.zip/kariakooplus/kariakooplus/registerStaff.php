<!-- App JS -->
<?php include 'includes/header.php'; ?>
<!-- * App JS -->

<body class="bg-white">

    <!-- loader -->
    <div id="loader">
        <img src="assets/img/logo-icon.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader">
        <div class="left">
            <a href="home" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">
            My Balance
        </div>
    </div>
    <!-- * App Header -->


    <!-- App Capsule -->
    <div id="appCapsule">
        <div class="section mt-2 mb-2">

            <div class="listed-detail mt-3">
                <div class="icon-wrapper">
                    <div class="iconbox">
                        <ion-icon name="file-tray-full-outline"></ion-icon>
                    </div>
                </div>
                <h3 class="text-center mt-2">Summary</h3>
            </div>



         <?php
            include 'getRequest.php';
            $url = 'report/getMemberBalance?Id='.$_SESSION["id"];
            $row = json_decode(getRequest($url),true);

            $income_num = $row[0]['income'];

            $deduction_num = $row[0]['deduction'];

            $ans = $row[0]['paid']/$row[0]['paid'];

            $paid_num = $ans*$income_num-$deduction_num;

            
            $balance_num = $income_num-$paid_num-$deduction_num;

            // Format in currency format
            $income = number_format($income_num);
            $deduction = number_format($deduction_num);
            $paid = number_format($paid_num);
            $balance = number_format($balance_num);

            ?>

            <ul class="listview flush transparent simple-listview no-space mt-3">
                <li>
                    <strong>Gross Income (Include all GRN)</strong>
                    <span><?php echo $income ;?></span>
                </li>
                <li>
                    <strong>Deduction (Cooporate deductions)</strong>
                    <span><?php echo $deduction ?></span>
                </li>
                <li>
                    <strong>Net Income (After deductions)</strong>
                    <span><?php echo number_format($income_num-$deduction_num) ?></span>
                </li>
                <li>
                    <strong>Paid (Amount you have received)</strong>
                    <span><?php echo $paid ?></span>
                </li>               
                <li>
                    <strong>Balance (Amount you owe us)</strong>
                    <h3 class="m-0"><?php echo $balance ?></h3>
                </li>
                <hr>
            </ul>

                          

        </div>

    </div>
    <!-- * App Capsule -->

    <!-- App Bottom Menu -->
    <?php include 'includes/bottom-menu.php'; ?>
    <!-- * App Bottom Menu -->

    <!-- App JS -->
    <?php include 'includes/scripts.php'; ?>
    <!-- * App JS -->

</body>

</html>